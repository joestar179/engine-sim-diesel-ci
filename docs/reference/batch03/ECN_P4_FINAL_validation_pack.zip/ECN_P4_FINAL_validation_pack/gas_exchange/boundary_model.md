# Gas-exchange boundary model and remaining plumbing gap

## Source-supported 0-D implementation

Busch et al. (SAE 2015-01-0796) model gas exchange by computing mass flow through the two intake
or two exhaust valves using the experimentally measured discharge coefficient and valve lift. The
reference area is twice the valve curtain area, A_R = 2*pi*D_v*L_v. The pressure boundary is the
measured static intake/exhaust pressure rather than a resolved runner-wave model.

For the ECN workbook pair, the measured Cd tables are normalized with reference diameters of
24 mm intake and 22 mm exhaust. Pairing those same reference diameters with the measured Cd and
lift is therefore the internally consistent 0-D mass-flow implementation. This is an R-grade model
closure, not a claim that 24/22 mm are independently measured valve-head outside diameters.

Use:
- intake: A_R = 2*pi*(24 mm)*L_intake
- exhaust: A_R = 2*pi*(22 mm)*L_exhaust
- Cd(L) from the native ECN tables, linearly interpolated in lift
- CdA(CAD) from `valve_effective_area_vs_CAD.csv`

The close-coupled pressure/HRR files already contain measured intake pressure versus crank angle.
That trace can be used directly as the intake pressure boundary for each case.

## True 1-D plumbing geometry

Perini et al. (SAE 2019-01-0204) states that the full-engine CFD geometry includes accurate intake
and exhaust plenums/surge tanks, runners, swirl plates, ports, valves, cylinder and optical piston.
However, the accessible paper text does not publish reducer-ready runner lengths, diameters or
surge-tank volumes.

Therefore:
- 0-D gas-exchange closure: supported without explicit pipe dimensions using measured boundary
  pressure + measured CdA.
- 1-D wave-dynamics plumbing: still U for lengths/IDs/volumes until the ECN STL/STEP geometry is
  dimensionally reduced.

Primary references:
- Busch et al., SAE 2015-01-0796, doi:10.4271/2015-01-0796.
- Perini et al., SAE 2019-01-0204, doi:10.4271/2019-01-0204.
