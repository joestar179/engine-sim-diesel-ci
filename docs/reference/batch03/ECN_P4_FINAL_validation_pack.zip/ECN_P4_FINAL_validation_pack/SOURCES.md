# Source notes

This file records the exact source location conventions used in the pack.

- `Crank-Slider Info.xlsx`: native ECN CFD download; Sheet1 cells B2/B3/B4/B5/B9/B11 etc.
- `Valve lift data.xlsx`: native ECN CFD download; `Rearranged` sheet for exported lift arrays.
- `GM 1_9 Flow Coefficients.xlsx`: native ECN CFD download; `Intake` and `Exhaust` sheets. Header contains the 24 mm / 22 mm reference diameters and 0.1 mm lash.
- `Conventional and Stepped-Lip Piston Bowl Profiles.xlsx`: native ECN CFD download; numeric bowl coordinates exported without plot digitisation.
- `Spray Targeting - bowl geometry study.xlsx` and `Spray Targeting - pilot main dwell study.xlsx`: native ECN CFD downloads; nozzle targeting / hole geometry.
- `Cylinder Pressure, Injection Rates, and Heat Release.zip`: native ECN bowl-study archive. Exported fired and non-combustion data to CSV; pressure grid is 0.25 CAD.
- `Liquid fuel behavior (Mie).zip`: native ECN bowl-study archive. Exported processed ensemble penetration/liquid-length and spreading-angle arrays. Embedded `Mie Operation Description.xlsx` supplies optical operating metadata.
- `Pressure and Heat Release.zip`: native ECN close-coupled archive; exported pressure and apparent-HRR arrays.
- `Injection Rate Profiles.zip`: native ECN close-coupled archive; exported energizing-current and HDA rate arrays.
- `LiquidLengthData.mat`: processed close-coupled Mie data. ECN TXT specifies 120 kfps, 8 pixels/mm, Naber/Siebers method, 3% intensity threshold.

Publication/table references already used in source reconciliation:
- Busch et al., SAE 2015-01-0796: experimental setup, valve-flow modeling convention, hydraulic-SOI definition, calculated cetane number.
- Perini et al. 2018 optical-engine paper: engine geometry / piston configuration tables.
- Perini et al., SAE 2019-01-0204: full-engine geometry / prescribed CFD wall temperatures and family boundary conditions.
- Sandia SAND2016-7721PE: close-coupled operating-point table.

Where the exact page/table number could not be re-established from the already-downloaded binary source, the pack cites the native workbook sheet/cell or archive filename rather than inventing a page number.
