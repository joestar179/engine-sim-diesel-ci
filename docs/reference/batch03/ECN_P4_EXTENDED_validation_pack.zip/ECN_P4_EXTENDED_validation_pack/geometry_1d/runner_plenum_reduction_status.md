# ECN 1-D runner / plenum reduction status

**Importance:** N (per extension request).

The ECN CFD documentation states that the full computational geometry includes the intake and exhaust runners and pressure-damping plenums. The direct conventional-engine STEP source is:

`https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/stl_conventional_flatTop.stp`

No reducer-ready lengths, equivalent diameters or plenum volumes are tabulated in the sources already extracted. The raw STEP file is not part of the uploaded source set and could not be retrieved into the local CAD-analysis runtime in this pass. Therefore:

- intake runner length / diameter: **U**
- exhaust runner length / diameter: **U**
- intake pressure-damping plenum / surge-tank volume: **U**
- exhaust pressure-damping plenum / surge-tank volume: **U**

No dimensions were estimated from figures. If the STEP is supplied later, dimensional reduction can be done as a separate geometry task.

Source: ECN CFD page: https://ecn.sandia.gov/engines/small-bore-diesel-engine/cfd/; Perini et al. IJER 2018 describes modeled runners and pressure-damping plenums.
