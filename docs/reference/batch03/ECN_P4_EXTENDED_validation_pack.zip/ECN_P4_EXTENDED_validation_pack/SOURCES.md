# Source notes

This file records the exact source location conventions used in the pack.

- `Crank-Slider Info.xlsx`: native ECN CFD download; Sheet1 cells B2/B3/B4/B5/B9/B11 etc.
- `Valve lift data.xlsx`: native ECN CFD download; `Rearranged` sheet for exported lift arrays.
- `GM 1_9 Flow Coefficients.xlsx`: native ECN CFD download; `Intake` and `Exhaust` sheets. Header contains the 24 mm / 22 mm reference diameters and 0.1 mm lash.
- `Conventional and Stepped-Lip Piston Bowl Profiles.xlsx`: native ECN CFD download; numeric bowl coordinates exported without plot digitisation.
- `Spray Targeting - bowl geometry study.xlsx` and `Spray Targeting - pilot main dwell study.xlsx`: native ECN CFD downloads; nozzle targeting / hole geometry.
- `Cylinder Pressure, Injection Rates, and Heat Release.zip`: native ECN bowl-study archive. Exported fired and non-combustion data to CSV; pressure grid is 0.25 CAD.
- `Liquid fuel behavior (Mie).zip`: native ECN bowl-study archive. Exported processed ensemble penetration/liquid-length and spreading-angle arrays. Embedded `Mie Operation Description.xlsx` supplies optical operating metadata.
- `Pressure and Heat Release.zip`: native ECN close-coupled archive; exported pressure and apparent-HRR arrays.
- `Injection Rate Profiles.zip`: native ECN close-coupled archive; exported energizing-current and HDA rate arrays.
- `LiquidLengthData.mat`: processed close-coupled Mie data. ECN TXT specifies 120 kfps, 8 pixels/mm, Naber/Siebers method, 3% intensity threshold.

Publication/table references already used in source reconciliation:
- Busch et al., SAE 2015-01-0796: experimental setup, valve-flow modeling convention, hydraulic-SOI definition, calculated cetane number.
- Perini et al. 2018 optical-engine paper: engine geometry / piston configuration tables.
- Perini et al., SAE 2019-01-0204: full-engine geometry / prescribed CFD wall temperatures and family boundary conditions.
- Sandia SAND2016-7721PE: close-coupled operating-point table.

Where the exact page/table number could not be re-established from the already-downloaded binary source, the pack cites the native workbook sheet/cell or archive filename rather than inventing a page number.


## Extension sources — fuel / boundary-gap pass

- ECN Fuels, **Table 2.5.1** — component densities at stated fuel temperature, formula, cetane, H/C, LHV and ECN stoichiometric A/F: https://ecn.sandia.gov/diesel-spray-combustion/sandia-cv/fuels/
- NIST Chemistry WebBook SRD 69 — HMN, C16H34, MW 226.4412, normal boiling point 513.2 K, ΔvapH 52.4 kJ/mol at 438 K: https://webbook.nist.gov/cgi/cbook.cgi?ID=C4390049&Mask=15&Units=SI
- NIST Chemistry WebBook SRD 69 — n-hexadecane, C16H34, MW 226.4412, normal boiling point 554 ±10 K, ΔvapH° 81.3 ±0.6 kJ/mol: https://webbook.nist.gov/cgi/cbook.cgi?ID=C544763&Mask=15&Units=SI
- Perini et al., SAE **2019-24-0167**, Table 5 — fired CDC9 boundary conditions incl. 353 K charge, N2/O2/CO2 composition and 145.7 kPa constant exhaust pressure: https://www.federicoperini.info/wp-content/uploads/2019Feb_AEC_Federico_GeometryEffects_Combustion_v6_ACADEMIA.pdf
- Perini et al., *International Journal of Engine Research* 2018, **Table 1** — related optical LTC condition: 1500 rpm, 1.5 bar, 372 K, 10% O2/81% N2/9% CO2: https://journals.sagepub.com/doi/full/10.1177/1468087417742572
- Sandia **SAND2016-7721PE** — close-coupled operating point: 1500 rpm, 150 kPa, 353 K, 19.73% O2, 7% external EGR / 10.3% incl. residual: https://www.osti.gov/servlets/purl/1375296

Unresolved after this bounded pass are retained as U/F; no additional generic-diesel values were substituted.
