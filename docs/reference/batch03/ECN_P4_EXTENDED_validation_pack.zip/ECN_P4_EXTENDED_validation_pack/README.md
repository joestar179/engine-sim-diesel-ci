# P4 — GM / Opel 1.9 L ECN small-bore diesel validation pack

**Purpose:** validation reference for a 0-D / 1-D diesel engine simulator and for shared spray / evaporation physics. **Cut-off:** this pack reflects the ECN files supplied and the source checks already completed in this investigation; unresolved items are left F/U rather than filled by generic values.

## Grading and use rules

- **D** — direct/exact configuration measurement or native ECN numeric file.
- **F** — family/related configuration; useful but not exact enough to silently substitute.
- **R** — derived from D/F data. Arithmetic/method is stated.
- **U** — not found / not established.
- **MODEL-DERIVED** — prescribed simulation parameter, not measured hardware.

No requested curve in this final pack is based on manual plot digitisation where native numeric ECN data were available. The earlier manually digitised close-coupled liquid-length example is **superseded** by `LiquidLengthData.mat` and is not used here.

## Configuration control — do not merge these builds

|Dataset / use|Hardware version|Piston / CR handling|Notes|
|---|---|---|---|
|Crank-slider / base geometry workbook|ECN research single-cylinder|1.36 mm squish; derived CR **15.8218:1**|Exact values from native workbook; use for p–V integration and the extracted pack unless a case-specific geometry supersedes it.|
|Bowl-study fired pressure/HRR|Optical/metal research engine|Conventional re-entrant and stepped-lip; **no valve cut-outs, equal squish** for thermodynamic comparison|Do not substitute the cut-out PIV piston geometry.|
|Close-coupled pressure/HRR|Research engine, conventional re-entrant with **four valve cut-outs**|Pressure tests use **titanium** piston top|Same close-coupled geometry family as optical study.|
|Close-coupled Mie liquid length|Optical research engine|Geometrically corresponding conventional re-entrant with four cut-outs|Uses **fused-silica** piston top; non-combusting N2 skip-fire.|
|2019 full-engine SL CFD / mixture study|Stepped-lip family|Published CR about **15.8:1**|Useful for prescribed wall temperatures and some family boundaries; keep F/MODEL-DERIVED when transferred.|

## A. HARDWARE — crank-slider, chamber and piston

|Parameter|Value|Grade|Exact source|
|---|---:|:---:|---|
|Bore|82.0 mm|D|`Crank-Slider Info.xlsx`, Sheet1 B2; ECN CFD page|
|Stroke|90.4 mm|D|`Crank-Slider Info.xlsx`, Sheet1 B3|
|Connecting rod|166.6748 mm|D|`Crank-Slider Info.xlsx`, Sheet1 B4|
|Pin offset|1.5875 mm|D|`Crank-Slider Info.xlsx`, Sheet1 B5|
|Squish height|1.36 mm|D|`Crank-Slider Info.xlsx`, Sheet1 B11|
|Displacement|0.477403959 L = 477.403959 cm³|R|Native crank-slider dimensions / workbook derived cell|
|Clearance volume|0.0322095263 L = 32.209526 cm³|R|Native chamber/crevice/bowl values in workbook|
|Compression ratio|**15.8218249:1**|R|`1 + Vd/Vc = 1 + 0.47740395946187353 / 0.032209526344150446`|
|Direct bowl volume|**23.44251 cm³**|D|`Crank-Slider Info.xlsx`, bowl-volume cell|
|Conventional bowl volume from supplied profile|23.46145 cm³|R|Numerical revolution of native radial profile|
|Stepped-lip bowl volume from supplied profile|23.45797 cm³|R|Numerical revolution of native radial profile|
|Valve cut-out volume, conventional reference|1.01511 cm³|D|`Crank-Slider Info.xlsx`; note says measured for conventional bowl and not included for flat-top pistons|
|Top-land crevice height|29.57 mm|D|`Crank-Slider Info.xlsx`|
|Valve-crevice / injector-gap volume|200 mm³|D|`Crank-Slider Info.xlsx`|

Native arrays: `geometry/crank_slider_volume.csv`, `geometry/piston_bowl_conventional_profile.csv`, `geometry/piston_bowl_stepped_lip_profile.csv`.

## B. HARDWARE — valves, lift, flow and swirl

- Native lift vs crank angle: `geometry/valve_lift.csv` (**D**). Maximum lift is **7.94956 mm intake** at −254.444 CAD aTDC and **7.94979 mm exhaust** at +247.739 CAD aTDC.
- Valve events from the embedded ECN operating workbook: **IVO −359, IVC −152, EVO +132, EVC +360 CAD aTDC** (**D**).
- Native measured Cd vs lift: `geometry/valve_flow_coefficients_intake.csv` and `geometry/valve_flow_coefficients_exhaust.csv` (**D**). Both forward/backward columns are retained.
- The flow workbooks define **24 mm intake** and **22 mm exhaust** reference diameters with **0.1 mm lash** (**D**). These are **not proven physical valve-head ODs**; physical head diameters remain **U**.
- Source-consistent 0-D valve area: Busch et al. use two-valve curtain area with measured lift and Cd. `gas_exchange/valve_effective_area_vs_CAD.csv` provides the resulting **R** CdA history. Peak two-valve CdA: **661.318 mm² intake**, **826.951 mm² exhaust**.
- Operating swirl: **2.2 Ricardo** for the extracted LTC3/CDC9 optical operating metadata (**D**). A **swirl-vs-lift curve is U**.

## C. HARDWARE / boundaries — intake and exhaust system

**0-D implementation is well supported:** each fired pressure file contains measured intake pressure vs CAD, and the measured valve Cd/lift can be used against a pressure-reservoir boundary. The full ECN CFD geometry includes plenums/surge tanks, runners, swirl plates and ports, but reducer-ready 1-D lengths, diameters and volumes have not been extracted; they remain **U**.

|Boundary item|Result|Grade|
|---|---|:---:|
|Intake pressure, bowl-study fired cases|Native trace in every fired CSV; case means 147.6–152.9 kPa|D trace / R mean|
|CDC9 fired intake temperature|353 K|D|
|LTC3 fired intake temperature|372 K|F|
|Close-coupled intake temperature|353 K|D|
|Close-coupled intake pressure target|150 kPa abs; native traces average ~150.3–150.9 kPa|D / R|
|CDC9 fired exhaust back-pressure|145.7 kPa abs, constant|D|
|LTC3 fired exhaust back-pressure|Not established|U|
|Close-coupled exhaust back-pressure|Not established|U|
|2019 SL family exhaust pressure|145.7 kPa abs|F|
|Surge-tank volumes / runner lengths / runner IDs|Not reduced from CAD|U|

See `gas_exchange/boundary_model.md` for the recommended 0-D closure and the remaining true-1-D gap.

## D. HARDWARE — injector, injection, spray and fuel

|Item|Value / data|Grade|Source|
|---|---|:---:|---|
|Nozzle|**7 × 139 µm**|D|ECN spray-targeting workbooks|
|Included spray angle|**149°**|D|ECN spray-targeting workbooks|
|Nozzle conicity|`ks = 1.5`|D|ECN spray-targeting workbook|
|Rail pressure CDC9 / close-coupled|**800 bar**|D|ECN operating metadata|
|Rail pressure LTC3|**860 bar**|D|ECN operating metadata|
|Fuel|**DPRF58: 58 vol% HMN + 42 vol% n-hexadecane**|D|ECN operating workbook / Sandia close-coupled material|
|Cetane|**50.7**|R|Busch et al. 2015; explicitly calculated rather than measured batch CN|
|LHV|**43.9 MJ/kg**|R|ECN Fuels Table 2.5.1: both components 43.9 MJ/kg; mixture unchanged|
|Volatility / distillation|Blend curve U; component normal boiling points 513.2 K HMN / 554 ±10 K nC16|U/R|NIST component phase-change data; not a substitute for blend T10/T50/T90|

### Injection arrays and hydraulic timing

- Bowl-study fired case CSVs contain native injection-rate traces (~0.09 CAD sampling) together with 0.25-CAD pressure/HRR traces.
- Close-coupled `injection_rate/*.csv` contains energizing current and measured HDA injection rate for **1200, 1000, 800, 600, 500, 400, 300, 200, 180, 160, 140, 120, 100, 80/90 µs and main-only**.
- Hydraulic SOI follows Busch et al.’s definition: last positively sloped zero crossing of measured ROI before the event. Electrical SSE is interpolated from the current zero crossing. Full results: `close_coupled/hydraulic_timing.csv`.

|Nominal dwell µs|Pilot electrical→hydraulic delay µs R|Main delay µs R|
|---:|---:|---:|
|1200|316.7|315.7|
|1000|314.6|313.5|
|800|319.0|314.7|
|600|317.5|306.4|
|500|317.4|288.6|
|400|317.4|305.1|
|300|317.4|312.7|
|200|316.4|206.0|
|180|315.8|225.0|
|160|317.3|140.3|
|140|318.5|158.5|
|120|318.3|175.3|
|100|315.6|189.4|
|80|318.9|183.1|
|main only||316.3|

### Spray / evaporation arrays

- Bowl study Mie: **40 kfps = 0.225 CAD/frame at 1500 rpm**. Twelve CSVs retain seven-jet penetration/liquid-length mean/std and Siebers spreading-angle mean/std. Paths: `bowl_study/mie/*.csv` (**D**).
- Close-coupled Mie: **120 kfps = 0.075 CAD/frame at 1500 rpm**, 8 pixels/mm after distortion correction, 3% per-jet/per-cycle intensity threshold. Paths: `close_coupled/liquid_length/*.csv` (**D**).
- `LiquidLengthData.mat` contains 45 individual-cycle columns per jet even though the accompanying ECN text states 46 injected cycles. The discrepancy is preserved explicitly.

## E. Temperatures

|Temperature|Value|Grade|Interpretation|
|---|---:|:---:|---|
|Coolant|363 K / 90 °C|D|Operating metadata for bowl-study optical cases|
|Oil|—|U|Not found|
|Piston surface|440 K|MODEL-DERIVED|Prescribed CFD boundary, not measured hardware|
|Liner|430 K|MODEL-DERIVED|Prescribed CFD boundary|
|Head|440 K|MODEL-DERIVED|Prescribed CFD boundary|
|Intake valve|370 K|MODEL-DERIVED|Prescribed CFD boundary|
|Exhaust valve|400 K|MODEL-DERIVED|Prescribed CFD boundary|

## Outputs — piston-bowl study

All fired cylinder-pressure traces are native **0.25 CAD** arrays. AHRR is supplied numerically by ECN but is a pressure-derived quantity, therefore graded **R**. IMEP below is independently derived as `∮p dV / Vd` using the extracted crank-slider volume curve. Companion “noncombustion” traces are inert-charge **injected** runs and are graded **F** against the literal same-charge fuel-off motored requirement.

|Case|Piston|Fuel mg/cycle D|Mean Pintake kPa R|Tin K|O₂ vol%|IMEPg bar R|Pmax kPa @ CAD|AHRR max J/CAD @ CAD|
|---|---|---:|---:|---:|---:|---:|---:|---:|
|CDC9_SL_SSEp17b|stepped-lip|24.24|147.57|353 (D)|19.70 (D)|9.061|7580 @ 11.75|68.58 @ 8.75|
|CDC9_SL_SSEp07b|stepped-lip|24.98|147.81|353 (D)|19.70 (D)|8.979|5521 @ 2.75|73.37 @ 16.75|
|CDC9_SL_SSEp02a|stepped-lip|30.53|147.70|353 (D)|19.70 (D)|9.071|5240 @ -1.25|148.60 @ 31.00|
|CDC9_Conv_SSEp17b|conventional re-entrant|24.01|149.32|353 (D)|19.70 (D)|9.038|7663 @ 11.50|69.80 @ 9.00|
|CDC9_Conv_SSEp07b|conventional re-entrant|25.76|148.86|353 (D)|19.70 (D)|9.058|5458 @ 2.25|69.93 @ 20.25|
|CDC9_Conv_SSEp02a|conventional re-entrant|30.97|149.28|353 (D)|19.70 (D)|9.103|5247 @ -1.00|100.56 @ 30.00|
|LTC3_SL_SSE36b|stepped-lip|10.74|152.78|372 (F)|10.00 (F)|3.100|7337 @ 2.75|41.94 @ -3.00|
|LTC3_SL_SSE27b|stepped-lip|9.38|152.19|372 (F)|10.00 (F)|3.035|6933 @ 4.50|37.53 @ 0.00|
|LTC3_SL_SSE12b|stepped-lip|9.35|152.62|372 (F)|10.00 (F)|3.002|5594 @ 10.50|35.98 @ 8.75|
|LTC3_Conv_SSE36b|conventional re-entrant|12.67|152.92|372 (F)|10.00 (F)|3.034|7283 @ 2.75|33.49 @ -2.75|
|LTC3_Conv_SSE27b|conventional re-entrant|9.41|152.34|372 (F)|10.00 (F)|3.063|6862 @ 4.00|39.52 @ -0.75|
|LTC3_Conv_SSE12b|conventional re-entrant|10.60|152.43|372 (F)|10.00 (F)|3.080|5472 @ 10.25|30.68 @ 8.75|

Files: `bowl_study/fired/*.csv`, `bowl_study/noncombustion/*.csv`, `bowl_study/operating_points_detailed.csv`. Speed is **1500 rpm D** for all cases. Exact fired EGR fraction is U; O₂ is reported directly where supported.

## Outputs — close-coupled pilot study

Exact common conditions: **1500 rpm, 150 kPa abs intake target, 353 K intake, 19.73 vol% O₂, 10.3% EGR including residual, 800 bar rail, DPRF58, 9 bar IMEPg target** (**D**). Total fuel below is **R**, integrated from the measured ROI; pressure is **D**, AHRR **R**, IMEP **R**.

|Case|Fuel mg/cycle R|Mean Pintake kPa R|IMEPg bar R|Pmax kPa @ CAD|AHRR max J/CAD @ CAD|
|---|---:|---:|---:|---:|---:|
|Dwell 1200 µs|25.53|150.92|8.992|7616 @ 13.00|68.99 @ 11.50|
|Dwell 1000 µs|25.80|150.81|9.097|7706 @ 13.00|67.90 @ 10.25|
|Dwell 0800 µs|24.59|150.67|8.995|7730 @ 12.25|67.04 @ 10.75|
|Dwell 0600 µs|24.59|150.93|8.990|7663 @ 13.00|65.42 @ 10.25|
|Dwell 0500 µs|24.64|150.85|9.085|7706 @ 12.50|68.27 @ 11.25|
|Dwell 0400 µs|24.37|150.60|9.016|7830 @ 12.50|62.34 @ 10.25|
|Dwell 0300 µs|24.73|150.42|9.029|7659 @ 13.00|63.75 @ 11.25|
|Dwell 0200 µs|25.14|150.35|9.069|7665 @ 13.00|66.55 @ 11.00|
|Dwell 0180 µs|25.22|150.48|9.084|7691 @ 13.00|66.35 @ 11.00|
|Dwell 0160 µs|23.42|150.30|9.072|7797 @ 12.75|69.52 @ 10.00|
|Dwell 0140 µs|24.00|150.61|9.018|7729 @ 13.00|73.38 @ 10.50|
|Dwell 0120 µs|24.28|150.66|8.971|7693 @ 13.25|74.66 @ 10.75|
|Dwell 0100 µs|24.09|150.51|8.975|7731 @ 12.75|72.08 @ 10.75|
|Dwell 0080 µs|24.61|150.76|9.044|7756 @ 13.00|70.74 @ 11.25|
|Main injection only|25.77|150.75|9.104|7751 @ 13.00|128.18 @ 6.75|

Files: `close_coupled/pressure_hrr/*.csv`, `close_coupled/injection_rate/*.csv`, `close_coupled/operating_points_detailed.csv`. A matching exact fuel-off motored trace was not identified (**U**).

## Motored / compression-reference status

- **Bowl study:** ECN companion files labelled non-combustion provide useful compression/heat-transfer reference traces, but they use inert N₂ or N₂/CO₂ and retain injection. They are therefore **F**, not silently relabelled as identical-condition fuel-off motoring.
- **Close-coupled:** no exact matching fuel-off motored trace was identified in the supplied files (**U**).

## MODEL-DERIVED — keep separate from hardware

- Piston 440 K, liner 430 K, head 440 K, intake valve 370 K, exhaust valve 400 K: **prescribed CFD boundary temperatures** from the 2019 full-engine SL study, not sensor measurements.
- The source close-coupled 0-D study also used estimated/scaled wall-temperature treatment; do not promote it to D hardware data.
- `gas_exchange/valve_effective_area_vs_CAD.csv` is **R**: computed from D lift, D Cd and the source-consistent flow-reference diameters.

## Remaining U / F items — explicit

1. **Physical valve-head OD**: U from ECN/Sandia. The 24/22 mm values are D flow-reference diameters, not independently proven head diameters.
2. **Swirl ratio vs valve lift**: U. Operating swirl 2.2 Ricardo is D.
3. **Exhaust back-pressure**: CDC9 fired is now **D = 145.7 kPa abs constant**; LTC3 fired remains U; close-coupled remains U. No crank-angle exhaust-pressure trace was located.
4. **1-D surge-tank / runner dimensions**: U until the ECN STEP is dimensionally reduced.
5. **Fuel LHV**: closed as **R = 43.9 MJ/kg** from ECN component data.
6. **Fuel volatility / distillation**: pure-component volatility data are available; a measured DPRF58 blend T10/T50/T90 curve remains U.
7. **Oil temperature**: U.
8. **Bowl fired intake temperature**: CDC9 is now **D = 353 K** from the exact fired boundary table; LTC3 remains **F = 372 K** from the related optical LTC family.
9. **LTC3 fired composition**: F at 10% O2 / 81% N2 / 9% CO2 from the related optical LTC condition; CDC9 is D at 19.7% O2 / 79.2% N2 / 1.1% CO2.
10. **Close-coupled constituent charge fractions**: O2 and EGR are D, but exact N2/CO2/H2O fractions remain U.
11. **Exact same-charge fuel-off motored pressure**: F substitute for bowl cases, U for close-coupled.
12. **Measured metal wall/head/piston temperatures**: U; prescribed CFD temperatures remain MODEL-DERIVED.

## Downloadable ECN source files

The complete direct-download inventory is in `download_inventory.csv`. It contains **27 ECN files** covering CFD geometry, numeric workbooks, thermodynamic archives and optical datasets. Key pages:

- CFD: https://ecn.sandia.gov/engines/small-bore-diesel-engine/cfd/
- Piston-bowl study: https://ecn.sandia.gov/engines/small-bore-diesel-engine/experimental-data/piston-bowl-geometry-study/
- Close-coupled study: https://ecn.sandia.gov/engines/small-bore-diesel-engine/experimental-data/close-coupled-pilot-injection-study/

### Direct-file inventory

|#|Group|File|Contents|
|---:|---|---|---|
|1|CFD geometry|[STL_conventional_flatTop.stl](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/STL_conventional_flatTop.stl)|Conventional full-engine STL|
|2|CFD geometry|[stl_conventional_flatTop.stp](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/stl_conventional_flatTop.stp)|Conventional full-engine STEP|
|3|CFD geometry|[ECN_Optical_Engine_Flat_top_540.00.stl](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/ECN_Optical_Engine_Flat_top_540.00.stl)|Closed-cylinder conventional geometry|
|4|CFD geometry|[ConventionalBowl_with_ValveCutouts.stl](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Piston_Bowls/ConventionalBowl_with_ValveCutouts.stl)|Conventional piston crown with valve cut-outs|
|5|CFD geometry|[ECN_Optical_Engine_w_Valve_Cutouts_540.00.stl](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/ECN_Optical_Engine_w_Valve_Cutouts_540.00.stl)|Closed engine with valve cut-outs|
|6|CFD geometry|[SmallBore_Full_Engine_SL_Piston.stl](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/SmallBore_Full_Engine_SL_Piston.stl)|Stepped-lip full-engine STL|
|7|CFD numeric|[Conventional and Stepped-Lip Piston Bowl Profiles.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Piston_Bowls/Conventional%20and%20Stepped-Lip%20Piston%20Bowl%20Profiles.xlsx)|Numeric piston bowl radial profiles|
|8|CFD numeric|[Crank-Slider Info.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Crank-Slider_Info/Crank-Slider%20Info.xlsx)|Crank-slider and clearance geometry|
|9|CFD numeric|[Valve lift data.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/ValveLift_and_Flow/Valve%20lift%20data.xlsx)|Intake/exhaust lift vs crank angle|
|10|CFD numeric|[GM 1_9 Flow Coefficients.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/ValveLift_and_Flow/GM%201_9%20Flow%20Coefficients.xlsx)|Measured intake/exhaust flow coefficients vs lift|
|11|CFD numeric|[Spray Targeting - bowl geometry study.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Spray%20Targeting/Spray%20Targeting%20-%20bowl%20geometry%20study.xlsx)|Injector targeting, bowl study|
|12|CFD numeric|[Spray Targeting - pilot main dwell study.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/CFD/Spray%20Targeting/Spray%20Targeting%20-%20pilot%20main%20dwell%20study.xlsx)|Injector targeting, close-coupled study|
|13|Bowl study|[Spray Targeting.xlsx](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Spray%20Targeting.xlsx)|Experimental bowl-study targeting workbook; duplicate of CFD targeting file in supplied set|
|14|Bowl study|[Cylinder Pressure, Injection Rates, and Heat Release.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Cylinder%20Pressure%2C%20Injection%20Rates%2C%20and%20Heat%20Release.zip)|Fired/non-combusting pressure, ROI, AHRR for CDC9/LTC3|
|15|Bowl study|[Cold flow (PIV).zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Cold%20flow%20%28PIV%29.zip)|Cold-flow PIV|
|16|Bowl study|[Liquid fuel behavior (Mie).zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Liquid%20fuel%20behavior%20%28Mie%29.zip)|Mie liquid penetration and spreading-angle data/images|
|17|Bowl study|[Fuel-air mixing (fuel tracer PLIF).zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Fuel-air%20mixing%20%28fuel%20tracer%20PLIF%29.zip)|Fuel-tracer PLIF|
|18|Bowl study|[SootNL.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/SootNL.zip)|Natural-luminosity soot imaging|
|19|Bowl study|[Late-cycle flow (CIV).zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Piston%20Bowl%20Geometry%20Study/Late-cycle%20flow%20%28CIV%29.zip)|Late-cycle CIV|
|20|Close-coupled|[Pressure and Heat Release.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/Pressure%20and%20Heat%20Release.zip)|Intake/cylinder pressure and AHRR, dwell sweep|
|21|Close-coupled|[Injection Rate Profiles.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/Injection%20Rate%20Profiles.zip)|HDA injection rate and energizing current, dwell sweep|
|22|Close-coupled|[Description of Mie scattering image data files.txt](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/Description%20of%20Mie%20scattering%20image%20data%20files.txt)|Mie image/data format and liquid-length methodology|
|23|Close-coupled|[High speed Mie scattering.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/High%20speed%20Mie%20scattering.zip)|120-kfps Mie images and LiquidLengthData.mat|
|24|Close-coupled|[Description of high-speed NL data files for CIV.txt](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/Description%20of%20high-speed%20NL%20data%20files%20for%20CIV.txt)|Natural-luminosity/CIV metadata|
|25|Close-coupled|[High speed NL.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/High%20speed%20NL.zip)|High-speed natural luminosity / CIV|
|26|Close-coupled|[Description of high-speed NL and OH data files.txt](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/Description%20of%20high-speed%20NL%20and%20OH%20data%20files.txt)|NL/OH metadata|
|27|Close-coupled|[High speed OH.zip](https://ecn.sandia.gov/Small-BoreDieselData/Experimental%20Data/Close-Coupled%20Pilot%20Injection%20Study/High%20speed%20OH.zip)|High-speed OH* chemiluminescence|

## Pack file map

- `ecn_p4_data.json` — strict `{name, value, unit, grade, importance, source}` records, including scalar values and references to native-array CSVs.
- `requirement_status.csv` — original-input/output checklist with importance and current grade.
- `download_inventory.csv` — direct ECN download URLs and contents.
- `geometry/` — chamber, valve lift, valve Cd and volume curves.
- `gas_exchange/` — CdA(CAD) and 0-D/1-D boundary note.
- `bowl_study/` — 12 fired cases, 12 non-combustion reference cases, 12 Mie case arrays and summaries.
- `close_coupled/` — 15 pressure/AHRR cases, 15 current/ROI cases, hydraulic timing, four processed liquid-length conditions.

## Principal literature / source references already used

- ECN Small-Bore Diesel Engine CFD and Experimental Data pages listed above.
- Busch et al., **SAE 2015-01-0796**, close-coupled pilot-injection experiment/model; hydraulic SOI definition and calculated DPRF58 cetane number.
- Perini et al., 2018 small-bore optical-engine / piston-bowl geometry work, including engine geometry and bowl configurations.
- Perini et al., **SAE 2019-01-0204**, full-engine stepped-lip CFD geometry / prescribed thermal boundaries.
- Sandia **SAND2016-7721PE**, close-coupled operating-point material: https://www.osti.gov/servlets/purl/1375296

## Validation readiness

For **closed-cycle diesel combustion, injection-rate, bowl sensitivity and liquid-spray/evaporation validation**, the pack is highly complete: native pressure, ROI, AHRR and optical arrays are present. The principal unresolved items are now narrower: LTC3 and close-coupled **exhaust back-pressure**, D-grade LTC3 fired charge metadata, close-coupled N2/CO2/H2O constituent fractions, physical valve-head OD, measured metal wall temperatures, and a true **1-D wave-action** manifold reduction. Fuel LHV and CDC9 fired exhaust pressure are closed in the extension below.
## Extension — targeted gap closure (2026-10-02)

This section extends the original pack without replacing any native-array CSV. Detailed machine-readable additions are in `fuel/`, `boundaries/`, `valves/`, `motored/`, `temperature/`, `geometry_1d/`, and `sources/`.

### [E] DPRF58 fuel properties

ECN Table 2.5.1 reports both DPRF58 constituents as **C16H34**. At **436 K and atmospheric pressure**, ECN gives **689 kg/m³** for HMN and **673 kg/m³** for n-hexadecane, with ±2 kg/m³ component-density uncertainty. It gives **43.9 MJ/kg LHV**, rounded atomic **H/(C−O)=2.13**, and **15.2 kg/kg** stoichiometric A/F for each component when mixed with ECN's specified simulated ambient (21% O2, 6.1% CO2, 3.6% H2O, 69.3% N2). Source: ECN Fuels, Table 2.5.1, https://ecn.sandia.gov/diesel-spray-combustion/sandia-cv/fuels/.

|Property|Value|Grade|Arithmetic / interpretation|
|---|---:|:---:|---|
|DPRF58 density at 436 K|**682.28 kg/m³**|R|`0.58×689 + 0.42×673 = 682.28` assuming additive component volumes because blend is specified by volume|
|HMN mass fraction implied at 436 K|0.585713|R|`0.58×689 / 682.28`|
|n-C16 mass fraction implied at 436 K|0.414287|R|`0.42×673 / 682.28`|
|LHV|**43.9 MJ/kg**|R|Both components are 43.9 MJ/kg, so any mass-weighted blend is 43.9|
|Exact molecular H/C|**2.125**|R|Both are C16H34: `34/16` (ECN table rounds to 2.13)|
|Stoich A/F, ECN simulated ambient|**15.2 kg/kg**|R|Both component entries are 15.2; ECN footnote defines the oxidizer composition|
|Stoich A/F, dry air 20.95% O2 /79.05% N2|**14.898668 kg/kg**|R|C16H34 needs 24.5 mol O2/mol fuel; full arithmetic in `fuel/DPRF58_properties.csv`|
|Measured DPRF58 T10/T50/T90 / distillation curve|—|U|Not found|
|HMN normal boiling point|513.2 K (240.05 °C)|F|NIST Chemistry WebBook SRD 69, https://webbook.nist.gov/cgi/cbook.cgi?ID=C4390049&Mask=15&Units=SI|
|n-C16 normal boiling point|554 ±10 K (280.85 ±10 °C)|F|NIST Chemistry WebBook SRD 69, https://webbook.nist.gov/cgi/cbook.cgi?ID=C544763&Mask=15&Units=SI|
|Component boiling-point envelope|513.2–554 K nominal|R|Volatility bracket only; **not** a measured blend distillation curve|

The requested blend volatility is therefore only **partially closed**: component phase-change data are good enough to define a surrogate evaporation model, but no measured DPRF58 distillation curve was located.

### [E] Fired charge composition, temperature and exhaust pressure

|Family|Tin|O2|N2|CO2|H2O|Dilution / EGR interpretation|Exhaust pressure|Grade / exactness|
|---|---:|---:|---:|---:|---:|---|---:|---|
|CDC9 bowl-study fired|**353 K**|**19.7%**|**79.2%**|**1.1%**|0% by difference|dry listed O2/N2/CO2 charge; no H2O listed|**145.7 kPa abs constant**|D for Tin/O2/N2/CO2/exhaust; H2O R|
|LTC3 bowl-study fired|372 K|10%|81%|9%|0% in related table|related optical LTC condition uses dry N2+CO2 dilution|U exact fired exhaust|**F**, not upgraded to D|
|Close-coupled fired|**353 K**|**19.73%**|U|U|U|**7% external EGR; 10.3% including residual**|U|D for Tin/O2/EGR; constituent fractions and exhaust U|

CDC9 source: Perini et al., SAE **2019-24-0167**, Table 5, https://www.federicoperini.info/wp-content/uploads/2019Feb_AEC_Federico_GeometryEffects_Combustion_v6_ACADEMIA.pdf. The table reports 151 kPa intake pressure, 353 K intake temperature, 79.2/19.7/1.1 vol% N2/O2/CO2, coolant 363 K and a constant 145.7 kPa exhaust boundary. These conditions are applied to the six CDC9 timing/piston cases in the ECN bowl-study family; the measured per-case intake-pressure traces remain the preferred pressure input.

LTC3 source: Perini et al., International Journal of Engine Research 2018, Table 1, https://journals.sagepub.com/doi/full/10.1177/1468087417742572, which gives 1500 rpm, 1.5 bar, 372 K, 10% O2/81% N2/9% CO2 for the related optical low-temperature condition. No exact fired bowl-study table was found in the bounded pass, so these remain **F** rather than D.

Close-coupled source: Sandia **SAND2016-7721PE**, https://www.osti.gov/servlets/purl/1375296. The retained operating-point material resolves O2 and EGR fraction but not N2/CO2/H2O mole fractions or exhaust back-pressure, so those fields remain U.

Full per-case table: `boundaries/fired_charge_and_exhaust_boundaries.csv`.

### [I] Physical valve-head diameters

Still **U** from ECN/Sandia sources. The native flow workbook's **24 mm intake / 22 mm exhaust** diameters remain explicitly classified as **flow-reference diameters**, not proven physical head ODs. No ECN/Sandia drawing or paper located in the bounded pass independently states the physical valve-head diameters. See `valves/physical_valve_head_diameter_status.csv`.

### [I] Same-charge fuel-off motored pressure

No exact same-charge fuel-off trace was established. The bowl-study archive's closest references remain the case-matched inert-charge, **injected** non-combusting traces already retained in `bowl_study/noncombustion/`; those remain **F** for the requested motored use. No close-coupled motored trace was identified. See `motored/motored_trace_status.csv`.

### [I] Measured metal-engine wall temperatures

No measured piston/head/liner temperatures were found. The previously retained **440 K piston / 440 K head / 430 K liner** values remain **MODEL-DERIVED prescribed CFD boundaries** and must not be relabelled as measurements. See `temperature/metal_wall_temperature_status.csv`.

### [N] 1-D runner / surge-tank reduction

The ECN full-engine STEP source is identified at `https://ecn.sandia.gov/Small-BoreDieselData/CFD/Engine_Geometry/stl_conventional_flatTop.stp`, and the literature confirms that runners and pressure-damping plenums are modeled. No lengths, equivalent diameters or plenum volumes were estimated from figures. The raw STEP was not present in the uploaded source set and could not be reduced in this pass, so these values remain **U**. See `geometry_1d/runner_plenum_reduction_status.md`.



### Extension machine-readable files

- `fuel/DPRF58_properties.csv` — blend properties, arithmetic, grades and exact sources.
- `fuel/DPRF58_component_properties.csv` — ECN/NIST component properties.
- `boundaries/fired_charge_and_exhaust_boundaries.csv` — per-case charge composition, Tin and exhaust-pressure status.
- `valves/physical_valve_head_diameter_status.csv` — exact gap status; does not conflate head OD with flow-reference diameter.
- `motored/motored_trace_status.csv` — exact vs closest compression-reference trace classification.
- `temperature/metal_wall_temperature_status.csv` — measured U vs prescribed MODEL-DERIVED wall boundaries.
- `geometry_1d/runner_plenum_reduction_status.md` — STEP source and unresolved dimensional reduction.
- `sources/additional_sources.csv` — exact extension-source inventory.
