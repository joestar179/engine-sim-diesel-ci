# ECN P4 pack extension changelog

Base pack: `ECN_P4_FINAL_validation_pack` (91 files).

The extended pack retains every base-pack path. Native curve/data CSVs are not removed or thinned. Metadata files were updated where new evidence superseded F/U status.

## Added

- `fuel/DPRF58_properties.csv`
- `fuel/DPRF58_component_properties.csv`
- `boundaries/fired_charge_and_exhaust_boundaries.csv`
- `valves/physical_valve_head_diameter_status.csv`
- `motored/motored_trace_status.csv`
- `temperature/metal_wall_temperature_status.csv`
- `geometry_1d/runner_plenum_reduction_status.md`
- `sources/additional_sources.csv`
- `PACK_CHANGELOG.md`
- `preservation_report.csv`

## Updated metadata (no native arrays dropped)

- `README.md` — full prior report retained with corrected/new gap status and extension section.
- `ecn_p4_data.json` — all prior records retained; every record now has `importance`; resolved fuel/CDC9 fields updated; new records appended.
- `requirement_status.csv` — latest E/I/N priorities and extension gaps added.
- `bowl_study/operating_points_detailed.csv` — appended N2/CO2/H2O/exhaust columns; CDC9 Tin upgraded F→D from exact fired table.
- `close_coupled/operating_points_detailed.csv` — appended EGR/composition/exhaust status columns.
- `SOURCES.md` — extension sources appended.
- `manifest.csv` — regenerated.
