# P3 — Kirloskar TV1 and AVL 5402 validation-grade data pack

## Scope and grading

Two engines are treated as **separate packs** and, within each engine family, different laboratory builds are not silently mixed.

- **D** — exact retained engine/test configuration.
- **F** — family/related build, or weaker exact-part evidence that is not sufficient for D.
- **R** — derived from D values; arithmetic/assumption shown.
- **U** — not found, not published, or not validation-grade for the retained setup.

Priority tags are the requested **[E] essential / [I] important / [N] nice-to-have**.

### Retained validation configurations

**TV1 retained setup:** Quadri, Rentala & Sarap, *World Journal of Engineering* 15(6), 2018, DOI `https://doi.org/10.1108/WJE-03-2017-0054`. Kirloskar TV-1, 3.5 kW, 1500 rpm, 661 cm³, full-load tests at 200/220/240 bar nozzle-opening pressure. Detailed pressure/NHRR data are only published at 220 bar. Pressure analysis is based on 100-cycle averages.

**AVL retained setup:** Pawlak et al., *Energy Science & Engineering* 14 (2026) 2248–2262, DOI `https://doi.org/10.1002/ese3.70482`. AVL 5402, 511 cm³, 1500 rpm, load sweep 10–39 N·m, 750 bar common rail, pilot 2.4 mg/cycle at 12° BTDC, main at 4° BTDC, +200 mbar intake overpressure. Pressure/VHRR figures are published at 25 and 35 N·m and represent 100-cycle averages.

### Essential completeness after bounded search

| Pack | Essential inputs exact/partial | Essential inputs incl. F | Essential outputs usable D/R |
|---|---:|---:|---:|
| TV1 retained Quadri setup | **34.6%** | **53.8%** | **83.3%** |
| AVL 5402 retained Pawlak setup | **63.6%** | **77.3%** | **83.3%** |

The common missing essential output is **absolute air mass flow**. The dominant remaining essential input gaps are TV1 pump internals/dynamic SOI and primary-confirmed AVL nozzle geometry.

---

# PACK 1 — Kirloskar TV1

## 1. Same physical test setup

The retained WJE study uses one TV-1 test rig with an eddy-current dynamometer. The engine is held at 1500 rpm, CR 17.5, and tested at full load at 200, 220 and 240 bar IOP. Performance is available at all three IOPs; crank-angle combustion traces are published only at 220 bar. No values from the separate AJAS/Data-in-Brief/ACS TV1 builds are promoted to D for this setup.

Source: `https://doi.org/10.1108/WJE-03-2017-0054` — p.712 Table III; p.713–714 setup; p.714 Table IV; p.716 Figs.8–10; p.717 Tables V–VI.

## 2. HARDWARE — requested inputs

| Priority | Parameter | Value | Grade | Source / note |
|---|---|---:|:---:|---|
| [E] | Bore | 87.5 mm | D | Quadri 2018 p.712 Table III |
| [E] | Stroke | 110 mm | D | same |
| [E] | Connecting rod | 234 mm | D | same |
| [E] | Compression ratio | 17.5:1 | D | same |
| [I] | Bowl type | hemispherical | D | same |
| [I] | Bowl diameter | U | U | not published |
| [I] | Bowl depth | U | U | not published |
| [I] | Bowl volume | U | U | not published |
| — | Total clearance volume | 40.061 cm³ | R | `661/(17.5-1)`; **not** bowl volume |
| [E] | Inlet valve head diameter | 34.0 mm | F | TV1-PH1/PHW1 replacement-valve catalogue `https://www.scribd.com/document/712497051/SPR-Enbine-Valve-Catalogue` |
| [E] | Exhaust valve head diameter | 34.0 mm | F | same |
| [E] | Max valve lift | 10.1 mm | F | different 5.2-kW TV1 build `https://www.scribd.com/document/376343478/11-Appendix` |
| [E] | Valve timing | IVO 4.5° BTDC; IVC 35.5° ABDC; EVO 35.5° BBDC; EVC 4.5° ATDC | F | different 4.4-kW build, ACS Omega Table 3 `https://pubs.acs.org/doi/10.1021/acsomega.3c00325`; threshold not stated |
| [N] | Valve clearance | U | U | not found for retained build |
| [I] | Intake pipe lengths/diameters, air-box volume | U | U | not published |
| [I] | Exhaust pipe lengths/diameters | U | U | not published |
| [I] | Air-flow measurement method | hot-wire transmitter, 0–250 mmWC, ±0.5%; U-tube differential manometer | D | Quadri 2018 p.714 Table IV |
| [E] | Pump type | Bosch/MICO PF1A / MICO inline, mechanical governor | F | TV1-family identification from `https://www.stationaryengineparts.com/bosch-pf1a-indian-petter-fuel-pump-element-bosch-9411038341-ehg.html` and `https://www.scribd.com/document/928748951/Complete-Parts-Catalog-International-2025` |
| [E] | Pump plunger diameter | U | U | TV1/JV1/AV1 element 9411038341 identified; dimension not found |
| [E] | Pump cam lift/rate | U | U | not found |
| [E] | Nozzle holes × diameter | **hole count U; diameter 0.15 mm D** | D partial | Quadri 2018 p.712 Table III |
| [E] | Dynamic SOI | U | U | only nominal/static timing published |
| [E] | Fuel LHV | 42.490 MJ/kg | F | separate AJAS TV1 fuel batch, p.16 Table 1 `https://thescipub.com/pdf/ajassp.2021.15.23.pdf` |
| [E] | Fuel density | 842.7 kg/m³ at 15.56°C | F | same |
| [I] | Static injection timing | 23° BTDC | D | Quadri 2018 p.712 Table III |
| [I] | Needle/nozzle opening pressure | 200, 220, 240 bar tested | D | retained test series |
| [I] | Spray included angle | U | U | not published for retained 0.15-mm nozzle |
| [I] | Injection-rate shape or duration | U | U | not measured/published |
| [I] | Cetane number | 51 | F | separate AJAS TV1 fuel batch |
| [N] | Spray penetration/liquid length | U | U | not found |
| [N] | Coolant temperature | U | U | sensor range only |
| [N] | Oil temperature | U | U | not published |

### Important TV1 configuration-mixing warning

Other TV1 papers use materially different heads/injectors/rated powers. A commonly reported 5.2-kW family build has ~34.2-mm valves, 10.1-mm lift and a three-hole injector; another 4.4-kW study reports different valve timing and a 3×0.3-mm injector. These are **F**, not substitutes for the retained 3.5-kW / 0.15-mm-nozzle Quadri build.

## 3. OUTPUTS — same retained setup

### Full-load pure-diesel operating points

| IOP | Speed | Torque / BMEP | Fuel flow | AIR FLOW | BSFC | p(θ) numeric | NHRR numeric |
|---:|---:|---|---:|---|---:|---|---|
| 200 bar | 1500 rpm D | 22.282 N·m / 0.4236 MPa R | 0.980 kg/h R | **U** | 0.280 kg/kWh D | U | U |
| **220 bar** | 1500 rpm D | 22.282 N·m / 0.4236 MPa R | 0.875 kg/h R | **U** | **0.250 kg/kWh D** | **D, digitised** | **D, digitised** |
| 240 bar | 1500 rpm D | 22.282 N·m / 0.4236 MPa R | 1.085 kg/h R | **U** | 0.310 kg/kWh D | U | U |

Torque derivation: `3.5e3*60/(2π*1500) = 22.282 N·m`.  
BMEP derivation: `4πT/0.000661 = 0.4236 MPa`.  
Fuel-flow derivation assumes the paper's “full load” equals the Table III rated 3.5 kW.

### Other requested outputs at 220 bar/full load

| Priority | Output | Value | Grade | Note |
|---|---|---|:---:|---|
| [E] | Cylinder pressure | full numeric trace, 300–440° CA at 1° spacing | D | figure-digitised from Fig.8 |
| [I] | Net heat-release rate | full numeric trace, 330–430° CA at 1° spacing | D | figure-digitised from Fig.9 |
| [I] | Exhaust temperature | U | U | thermocouple instrumentation exists but no operating-point EGT table |
| [I] | Motoring pressure / friction | U | U | not found |
| [N] | Ignition delay | U | U | no same-point validation-grade scalar |
| [N] | Combustion duration | U | U | CA50 published, but no same-point duration |
| [N] | Governor characteristic | qualitative constant-speed governor action only | D qualitative | quantitative speed/load droop curve U |

Exact Table VI scalar anchors at 220 bar pure diesel:
- peak pressure **56.99 bar**;
- peak NHRR **44.53 J/°CA**;
- CA at 50% mass fraction burned **9.18° CA as published**.

### TV1 digitisation method and uncertainty

Figures 8–9 were rendered from the uploaded publisher PDF at 400 dpi, axes calibrated, and the plotted traces extracted at **1° CA** spacing. These are figure-derived D values, **not author raw DAQ**.

Cross-check against Table VI:
- digitised pure-diesel pressure peak = **57.943 bar at 372° CA**, versus Table VI 56.99 bar;
- digitised pure-diesel NHRR peak = **48.834 J/°CA at 364° CA**, versus Table VI 44.53 J/°CA.

The source itself is not perfectly self-consistent: Fig.8 places pressure maxima near ~370° CA, while the prose reports the 20% HCNG maximum pressure at 362.64° CA. For validation, use **Table VI for exact scalar peak checks** and the digitised curves for **shape/phasing**.

### TV1 pure-diesel numeric trace pairs — 220 bar, full load

`p(θ)` is in bar; `NHRR` is J/°CA. “—” means that figure does not cover that crank-angle range.

| CA (deg) | p (bar) | NHRR (J/degCA) |
|---:|---:|---:|
| 300 | 8.370 | — |
| 301 | 8.470 | — |
| 302 | 8.569 | — |
| 303 | 8.669 | — |
| 304 | 8.769 | — |
| 305 | 8.868 | — |
| 306 | 9.018 | — |
| 307 | 9.117 | — |
| 308 | 9.267 | — |
| 309 | 9.416 | — |
| 310 | 9.516 | — |
| 311 | 9.665 | — |
| 312 | 9.815 | — |
| 313 | 9.964 | — |
| 314 | 10.114 | — |
| 315 | 10.313 | — |
| 316 | 10.512 | — |
| 317 | 10.662 | — |
| 318 | 10.911 | — |
| 319 | 11.110 | — |
| 320 | 11.310 | — |
| 321 | 11.559 | — |
| 322 | 11.808 | — |
| 323 | 12.007 | — |
| 324 | 12.306 | — |
| 325 | 12.555 | — |
| 326 | 12.804 | — |
| 327 | 13.153 | — |
| 328 | 13.502 | — |
| 329 | 13.801 | — |
| 330 | 14.149 | -1.690 |
| 331 | 14.498 | -1.690 |
| 332 | 14.897 | -1.690 |
| 333 | 15.295 | -1.690 |
| 334 | 15.694 | -1.690 |
| 335 | 16.192 | -1.690 |
| 336 | 16.591 | -1.814 |
| 337 | 17.089 | -1.938 |
| 338 | 17.637 | -2.062 |
| 339 | 18.185 | -2.186 |
| 340 | 18.733 | -2.248 |
| 341 | 19.331 | -2.248 |
| 342 | 19.929 | -2.186 |
| 343 | 20.576 | -2.062 |
| 344 | 21.274 | -2.062 |
| 345 | 21.971 | -1.938 |
| 346 | 22.619 | -2.000 |
| 347 | 23.267 | -2.000 |
| 348 | 23.964 | -2.000 |
| 349 | 24.612 | -1.876 |
| 350 | 25.260 | -1.503 |
| 351 | 25.957 | -1.131 |
| 352 | 26.555 | -0.634 |
| 353 | 27.352 | -0.014 |
| 354 | 27.950 | 0.607 |
| 355 | 28.548 | 1.103 |
| 356 | 29.146 | 1.848 |
| 357 | 29.644 | 2.717 |
| 358 | 30.192 | 4.145 |
| 359 | 30.740 | 6.814 |
| 360 | 31.288 | 12.090 |
| 361 | 32.285 | 20.593 |
| 362 | 33.779 | 31.890 |
| 363 | 35.623 | 43.310 |
| 364 | 38.513 | 48.834 |
| 365 | 42.498 | 47.531 |
| 366 | 46.683 | 41.510 |
| 367 | 51.018 | 35.986 |
| 368 | 54.057 | 32.262 |
| 369 | 56.100 | 29.097 |
| 370 | 57.345 | 27.110 |
| 371 | 57.893 | 25.248 |
| 372 | 57.943 | 23.572 |
| 373 | 57.694 | 22.145 |
| 374 | 57.096 | 20.779 |
| 375 | 56.399 | 19.600 |
| 376 | 55.502 | 18.359 |
| 377 | 54.555 | 17.366 |
| 378 | 53.509 | 16.497 |
| 379 | 52.164 | 15.503 |
| 380 | 50.868 | 14.634 |
| 381 | 49.473 | 13.641 |
| 382 | 48.078 | 12.897 |
| 383 | 46.683 | 12.276 |
| 384 | 45.238 | 11.655 |
| 385 | 43.794 | 11.034 |
| 386 | 42.448 | 10.414 |
| 387 | 41.004 | 9.793 |
| 388 | 39.409 | 9.235 |
| 389 | 38.064 | 8.552 |
| 390 | 36.719 | 8.055 |
| 391 | 35.423 | 7.621 |
| 392 | 34.178 | 7.186 |
| 393 | 32.932 | 6.814 |
| 394 | 31.737 | 6.441 |
| 395 | 30.641 | 6.131 |
| 396 | 29.495 | 5.821 |
| 397 | 28.349 | 5.510 |
| 398 | 27.302 | 5.262 |
| 399 | 26.356 | 5.076 |
| 400 | 25.459 | 4.828 |
| 401 | 24.562 | 4.579 |
| 402 | 23.715 | 4.269 |
| 403 | 22.918 | 3.959 |
| 404 | 22.221 | 3.586 |
| 405 | 21.424 | 3.152 |
| 406 | 20.726 | 2.779 |
| 407 | 20.128 | 2.407 |
| 408 | 19.530 | 2.159 |
| 409 | 18.932 | 2.034 |
| 410 | 18.334 | 1.910 |
| 411 | 17.836 | 1.786 |
| 412 | 17.338 | 1.662 |
| 413 | 16.840 | 1.538 |
| 414 | 16.342 | 1.352 |
| 415 | 15.893 | 1.165 |
| 416 | 15.495 | 0.979 |
| 417 | 15.096 | 0.793 |
| 418 | 14.697 | 0.607 |
| 419 | 14.349 | 0.483 |
| 420 | 14.000 | 0.359 |
| 421 | 13.701 | 0.234 |
| 422 | 13.402 | 0.172 |
| 423 | 13.004 | 0.110 |
| 424 | 12.705 | -0.014 |
| 425 | 12.505 | -0.076 |
| 426 | 12.206 | -0.138 |
| 427 | 12.007 | -0.200 |
| 428 | 11.708 | -0.262 |
| 429 | 11.509 | -0.262 |
| 430 | 11.310 | -0.324 |
| 431 | 11.110 | — |
| 432 | 10.911 | — |
| 433 | 10.712 | — |
| 434 | 10.512 | — |
| 435 | 10.313 | — |
| 436 | 10.213 | — |
| 437 | 10.014 | — |
| 438 | 9.915 | — |
| 439 | 9.765 | — |
| 440 | 9.665 | — |

Full all-fuel traces (pure diesel, 10% HCNG, 20% HCNG) are also supplied in the accompanying CSV/JSON.

## 4. Secondary TV1 datasets kept separate

- **AJAS 2021**: separate TV1 build/fuel batch; LHV 42.490 MJ/kg, density 842.7 kg/m³, CN 51. Its reported power/BSFC/fuel-flow numbers are internally inconsistent and are not used as a self-consistent brake-validation point.
- **Data in Brief 2021**: separate TV1 series; BSFC at 220 bar versus load fraction = `[(25%,0.480),(50%,0.380),(75%,0.311),(100%,0.281)] kg/kWh`; 20-mm metering orifice is reported for that rig only.
- **Family valve/pump sources**: retained as F only.

## 5. MODEL-DERIVED — TV1

No simulation-only parameters (discharge coefficients, empirical burn-law constants, friction multipliers, heat-transfer multipliers, spray-model constants) are promoted into HARDWARE. R-grade arithmetic such as torque/BMEP/fuel flow is **derived experimental bookkeeping**, not a model parameter.

## 6. TV1 downloadable/source files located

1. Retained Quadri article/DOI: `https://doi.org/10.1108/WJE-03-2017-0054` — geometry, setup, instrumentation, performance, combustion figures/tables.
2. ResearchGate mirror: `https://www.researchgate.net/publication/328519854_Performance_combustion_and_exhaust_emissions_analysis_of_HCNG_fuelled_single_cylinder_diesel_engine_at_different_injection_opening_pressures`.
3. AJAS 2021 direct PDF: `https://thescipub.com/pdf/ajassp.2021.15.23.pdf` — separate fuel batch/performance.
4. Data in Brief article: `https://www.sciencedirect.com/science/article/pii/S2352340921001220` — separate load-series data.
5. ACS Omega TV1 article: `https://pubs.acs.org/doi/10.1021/acsomega.3c00325` — different build, family timing only.
6. MICO parts-catalog mirror: `https://www.scribd.com/document/928748951/Complete-Parts-Catalog-International-2025` — pump-element identity.
7. PF1A/TV1 pump page: `https://www.stationaryengineparts.com/bosch-pf1a-indian-petter-fuel-pump-element-bosch-9411038341-ehg.html` — family pump association.
8. TV1 replacement-valve catalogue: `https://www.scribd.com/document/712497051/SPR-Enbine-Valve-Catalogue`.
9. TV1 family appendix: `https://www.scribd.com/document/376343478/11-Appendix` — max-lift family value.
10. Different TV1 injector study: `https://www.ijraset.com/fileserve.php?FID=12943`.

No public raw pressure/HRR CSV/XLS or exact test-cell pipe-geometry file surfaced.

---

# PACK 2 — AVL 5402, Pawlak 2026 retained setup

## 1. Same physical test setup

Pawlak et al. use an AVL 5402 at **1500 rpm** over **10–39 N·m**. All fuels share the same injection strategy: **750 bar**, **2.4 mg/cycle pilot at 12° BTDC**, **main at 4° BTDC**, and **+200 mbar intake overpressure**. Cylinder-pressure diagrams are recorded over **100 cycles**. Figures 5 and 6 publish VHRR/temperature/pressure at 25 and 35 N·m; Figure 10 publishes thermal efficiency and λ across the load sweep.

Source: `https://doi.org/10.1002/ese3.70482` — p.2253 Table 2; p.2253–2254 setup/methodology; p.2255 Figs.5–6; p.2259 Fig.10.

The Sarangi 2015 AVL 5402 and AVL 5402.030 manual are **supporting F sources only** and are never silently merged into the Pawlak exact build.

## 2. HARDWARE — requested inputs

| Priority | Parameter | Value | Grade | Source / note |
|---|---|---:|:---:|---|
| [E] | Bore | 85.01 mm | D | Pawlak Table 2 |
| [E] | Stroke | 90.00 mm | D | Pawlak Table 2 |
| [E] | Connecting rod | 148 mm | F | AVL 5402.030 manual; Pawlak does not state it |
| [E] | Compression ratio | 17:1 | D | Pawlak Table 2 |
| [I] | Bowl diameter | U | U | not published for Pawlak piston |
| [I] | Bowl depth | U | U | not published |
| [I] | Bowl volume | U | U | not published |
| — | Total clearance volume | 31.938 cm³ | R | `511/(17-1)`; **not** bowl volume |
| [E] | Inlet valve head OD | 30.6 mm | F | AVL 5402.030 manual |
| [E] | Exhaust valve head OD | 29.9 mm | F | AVL 5402.030 manual |
| [E] | Max valve lift | 8.5 mm | F | manual, with 0.3-mm clearance |
| [E] | Lift/timing threshold | exhaust 2 mm at 16.5° before BDC; inlet 2 mm at 22.5° after TDC | F | manual timing check |
| — | Pawlak valve open/close | inlet 346/586.5; exhaust 128.5/376.5; overlap 80 | D | Pawlak Table 2; preserve author's CA convention |
| [N] | Valve clearance | 0.30 mm inlet/exhaust | F | manual |
| [I] | Intake 1-D pipe geometry | U | U | no segment dimensions/plenum volume |
| [I] | Exhaust 1-D pipe geometry | U | U | family manual only specifies ≥500-mm flexible section, insufficient for network definition |
| [I] | Air-flow measurement method | U for absolute mass flow | U | Pawlak reports AVL LA4 λ measurement, not an air-mass-flow meter/table |
| [E] | Rail pressure | **750 bar** | D | Pawlak methodology |
| [E] | Nozzle holes × diameter | **candidate 8×0.120 mm** | F | exact DLLA162P2160 aftermarket listing `https://www.vertexcel.it/en/nozzle-dlla162p2160-bosch-dlla162p2160-0433172160.html`; conflicting aftermarket evidence means not D |
| [E] | Dynamic SOI — pilot | **12° BTDC** | D | Pawlak |
| [E] | Dynamic SOI — main | **4° BTDC** | D | Pawlak |
| [E] | Diesel LHV | **43.2 MJ/kg** | D | Pawlak Table 1 |
| [E] | Diesel density | **814.0 kg/m³ at 15°C** | D | Pawlak Table 1 |
| [I] | Static timing | U / not separately applicable | U | electronic common-rail SOI is the relevant exact timing |
| [I] | Needle opening pressure | U / not conventional pop-pressure input | U | not published |
| [I] | Spray included angle | candidate 152° | F | same aftermarket exact-part listing only |
| [I] | Injection-rate shape/duration | U | U | no measured numeric rate trace |
| [I] | Cetane number | 52 | F | Sarangi fuel, different AVL build |
| [N] | Spray penetration/liquid length | U | U | not found |
| [N] | Coolant temperature | Pawlak U; 80°C family-study value | F | Sarangi, different build |
| [N] | Oil temperature | Pawlak U; 90°C family-study value | F | Sarangi, different build |
| — | Common-rail fuel temperature | **70°C** | D | Pawlak setup |

## 3. OUTPUTS — Pawlak diesel-oil load sweep

Figure 10's ηth and λ paths were extracted directly from the embedded PDF vector graphics at the seven plotted load points. Brake power/BMEP are R from torque/speed. BSFC is R from `3.6/(ηth·LHV)`; fuel flow is R from `BSFC × brake power`. These are not a replacement for the unpublished raw Cori-Flow table.

| Torque | Speed | Brake power | BMEP | Fuel flow | AIR FLOW | BSFC | Numeric cylinder pressure |
|---:|---:|---:|---:|---:|---|---:|---|
| 10 | 1500 | 1.5708 R | 0.2459 R | 0.27364 R | U | 0.17420 R | U: no numeric p(θ) published |
| 15 | 1500 | 2.3562 R | 0.3689 R | 0.40675 R | U | 0.17263 R | U: no numeric p(θ) published |
| 20 | 1500 | 3.1416 R | 0.4918 R | 0.53104 R | U | 0.16903 R | U: no numeric p(θ) published |
| 25 | 1500 | 3.9270 R | 0.6148 R | 0.67711 R | U | 0.17242 R | D: p(θ)+VHRR |
| 30 | 1500 | 4.7124 R | 0.7378 R | 0.84029 R | U | 0.17831 R | U: no numeric p(θ) published |
| 35 | 1500 | 5.4978 R | 0.8607 R | 1.02584 R | U | 0.18659 R | D: p(θ)+VHRR |
| 39 | 1500 | 6.1261 R | 0.9591 R | 1.20322 R | U | 0.19641 R | U: no numeric p(θ) published |

### 25 and 35 N·m combustion outputs

The PDF stores Figures 5–6 as vector polylines; therefore the plotted 1°-CA points were extracted directly rather than read from pixels.

| Output | 25 N·m | 35 N·m | Grade |
|---|---:|---:|:---:|
| Peak cylinder pressure | 8.4871 MPa @ 9° ATDC | 8.8738 MPa @ 10° ATDC | D figure-extracted |
| Peak VHRR | 109.67 kJ/m³/°CA @ 5° ATDC | 111.70 kJ/m³/°CA @ 6° ATDC | D figure-extracted |
| SOC | -6.616° ATDC | -6.924° ATDC | D figure-extracted |
| MFB50 | 6.831° ATDC | 9.153° ATDC | D figure-extracted |
| Pilot-SOI→SOC ignition delay | 5.384° CA | 5.076° CA | R |
| MFB5→MFB90 duration | 25.090° CA | 35.234° CA | R |
| Exhaust temperature | U | U | U |
| Motoring trace / friction | U | U | U |

**Important:** Pawlak publishes **VHRR** (kJ/m³/°CA), not total heat-release rate in J/°CA. A total-HRR conversion is not supplied because it would add further assumptions. The numeric pressure/VHRR fragments span **−20 to +30° ATDC**, not the full 720° cycle.

The paper reports a maximum in-cylinder pressure measurement error of ±0.4%. Fuel-consumption measurement hardware is a Bronkhorst Cori-Flow with stated maximum error ±0.77%, but the point-by-point raw fuel-flow table is not published.

### AVL diesel numeric pairs — 25 N·m, 1500 rpm

| CA (deg ATDC) | p (MPa) | VHRR (kJ/m3/degCA) |
|---:|---:|---:|
| -20 | 2.61055 | -2.19032 |
| -19 | 2.74461 | -1.91585 |
| -18 | 2.88472 | -1.55816 |
| -17 | 3.02912 | -2.07269 |
| -16 | 3.17747 | -2.25331 |
| -15 | 3.32865 | -2.04774 |
| -14 | 3.48225 | -2.24381 |
| -13 | 3.63617 | -2.48263 |
| -12 | 3.78977 | -2.55987 |
| -11 | 3.94240 | -3.22648 |
| -10 | 4.08139 | -3.45580 |
| -9 | 4.21924 | -2.69295 |
| -8 | 4.35354 | 0.36440 |
| -7 | 4.50747 | 2.33213 |
| -6 | 4.64395 | 15.01187 |
| -5 | 4.90770 | 41.08432 |
| -4 | 5.29913 | 31.61402 |
| -3 | 5.42746 | 5.80298 |
| -2 | 5.49868 | 3.62971 |
| -1 | 5.56305 | 23.37711 |
| 0 | 5.80799 | 69.72100 |
| 1 | 6.32597 | 78.57458 |
| 2 | 6.60046 | 68.14417 |
| 3 | 6.93124 | 89.55989 |
| 4 | 7.35191 | 105.90774 |
| 5 | 7.74883 | 109.66734 |
| 6 | 8.09262 | 108.11669 |
| 7 | 8.35605 | 96.96026 |
| 8 | 8.48550 | 77.07503 |
| 9 | 8.48712 | 58.16532 |
| 10 | 8.39045 | 45.86819 |
| 11 | 8.24234 | 40.83955 |
| 12 | 8.06024 | 37.62058 |
| 13 | 7.85220 | 34.40640 |
| 14 | 7.62761 | 31.37995 |
| 15 | 7.38704 | 27.29119 |
| 16 | 7.13087 | 24.91231 |
| 17 | 6.87584 | 25.70250 |
| 18 | 6.62380 | 23.50784 |
| 19 | 6.36489 | 19.21351 |
| 20 | 6.10178 | 17.38480 |
| 21 | 5.84869 | 15.86860 |
| 22 | 5.59995 | 15.34932 |
| 23 | 5.35906 | 14.39994 |
| 24 | 5.12575 | 12.14939 |
| 25 | 4.89874 | 11.17386 |
| 26 | 4.68166 | 9.41286 |
| 27 | 4.47072 | 7.51764 |
| 28 | 4.26915 | 7.65073 |
| 29 | 4.07864 | 7.70298 |
| 30 | 3.89669 | 6.20818 |

### AVL diesel numeric pairs — 35 N·m, 1500 rpm

| CA (deg ATDC) | p (MPa) | VHRR (kJ/m3/degCA) |
|---:|---:|---:|
| -20 | 2.61578 | -1.95549 |
| -19 | 2.75109 | -1.65608 |
| -18 | 2.89246 | -1.36612 |
| -17 | 3.03787 | -1.81055 |
| -16 | 3.18836 | -1.81766 |
| -15 | 3.34192 | -1.76182 |
| -14 | 3.49653 | -1.97214 |
| -13 | 3.65316 | -2.08263 |
| -12 | 3.80923 | -2.24780 |
| -11 | 3.96408 | -3.03444 |
| -10 | 4.10424 | -3.29821 |
| -9 | 4.24408 | -2.12422 |
| -8 | 4.38391 | 1.75895 |
| -7 | 4.54861 | 3.12302 |
| -6 | 4.68457 | 37.52014 |
| -5 | 5.19459 | 40.51688 |
| -4 | 5.33475 | 8.48674 |
| -3 | 5.46877 | 5.02660 |
| -2 | 5.52690 | 10.78123 |
| -1 | 5.68345 | 34.42956 |
| 0 | 5.95771 | 52.31253 |
| 1 | 6.25402 | 67.27125 |
| 2 | 6.62428 | 82.60311 |
| 3 | 7.01520 | 90.53458 |
| 4 | 7.38627 | 100.84852 |
| 5 | 7.77930 | 110.70969 |
| 6 | 8.13607 | 111.69950 |
| 7 | 8.41865 | 108.61007 |
| 8 | 8.62840 | 106.59364 |
| 9 | 8.79028 | 102.78296 |
| 10 | 8.87384 | 86.47202 |
| 11 | 8.82540 | 69.83549 |
| 12 | 8.71043 | 59.49185 |
| 13 | 8.53394 | 49.75188 |
| 14 | 8.32088 | 45.56454 |
| 15 | 8.09683 | 42.74603 |
| 16 | 7.85430 | 38.39946 |
| 17 | 7.59861 | 36.84879 |
| 18 | 7.34106 | 34.32737 |
| 19 | 7.07729 | 31.27953 |
| 20 | 6.81352 | 29.49478 |
| 21 | 6.55347 | 26.72976 |
| 22 | 6.29665 | 25.82908 |
| 23 | 6.04507 | 24.03722 |
| 24 | 5.79906 | 21.66074 |
| 25 | 5.56113 | 20.20989 |
| 26 | 5.32942 | 17.64449 |
| 27 | 5.10505 | 15.85738 |
| 28 | 4.89021 | 15.06600 |
| 29 | 4.68328 | 14.38278 |
| 30 | 4.48580 | 12.94024 |

All six fuels in the Pawlak paper (DO, JP-8 and four JP-8/WRO blends) are supplied in the accompanying vector-extracted CSV/JSON.

## 4. Supporting AVL-family evidence kept separate

### AVL 5402.030 manual — F for Pawlak
Useful family hardware: 148-mm rod; 30.6/29.9-mm valve ODs; 8.5-mm lift; 0.30-mm clearance; 2-mm valve timing-check points. Manual: `https://www.scribd.com/document/857955153/5402-030-Manual`.

### Sarangi et al. 2015 — separate AVL 5402 build, F for Pawlak
This build uses CR 17.1, 148-mm rod, CP3 common rail and a VCO **5×0.18-mm / 142°** nozzle; fuel LHV 42.6 MJ/kg, density 840 kg/m³, CN 52; coolant 80°C and oil 90°C. Source: `https://journals.sagepub.com/doi/10.1177/0954407014548737`. These values are **not Pawlak D values**.

### Sensors 2020 — separate AVL 5402 setup
A fuel-cut/non-fired sequence exists and is useful qualitatively for motoring-type pressure-repeatability work, but it is not the Pawlak setup and does not supply a same-point FMEP/motoring validation trace. Source: `https://doi.org/10.3390/s20123478`.

## 5. MODEL-DERIVED — AVL

No simulation-only calibrated constants are promoted into HARDWARE. The figure-extracted VHRR is an experimental-analysis output from AVL Concerto, not a physical hardware parameter. Derived BMEP/BSFC/fuel-flow/phasing durations are R and explicitly labelled.

## 6. AVL downloadable/source files located

1. Pawlak 2026 Wiley article/PDF: `https://doi.org/10.1002/ese3.70482` — retained setup, Table 1/2, Figs.5–10. The paper states that supporting data are available from the corresponding author on reasonable request.
2. AVL 5402.030 manual mirror: `https://www.scribd.com/document/857955153/5402-030-Manual` — family hardware.
3. Sarangi et al. 2015 SAGE article: `https://journals.sagepub.com/doi/10.1177/0954407014548737` — separate AVL build.
4. Sensors 2020 article/PDF: `https://doi.org/10.3390/s20123478` — separate fuel-cut/non-fired sequence.
5. DLLA162P2160 exact-part aftermarket listing: `https://www.vertexcel.it/en/nozzle-dlla162p2160-bosch-dlla162p2160-0433172160.html` — candidate 8×0.120 mm / 152°, not primary-confirmed.

No public raw DAQ CSV/XLS, exact Pawlak air-flow table, injection-rate trace, full-cycle motoring trace, or complete 1-D test-cell geometry file surfaced in the bounded search.

---

# Cross-pack validation assessment

## What is validation-ready

**TV1**
- exact core geometry;
- exact static injection timing / IOP series;
- full-load BSFC at 200/220/240 bar;
- 220-bar pure-diesel numeric p(θ) and NHRR shapes;
- same-rig output comparison across IOP.

**AVL 5402 Pawlak**
- exact bore/stroke/CR, rail pressure and dynamic pilot/main SOI;
- exact diesel LHV/density;
- exact load/speed points;
- numeric p(θ) and VHRR at 25 and 35 N·m;
- derived BSFC/fuel flow across seven load points;
- SOC/MFB phasing at 25 and 35 N·m.

## Remaining material gaps

**TV1 essential:** pump plunger diameter, pump-cam profile/rate, exact valve hardware, exact retained injector hole count, dynamic SOI, retained fuel-batch LHV/density, absolute air flow.

**AVL essential:** primary confirmation of DLLA162P2160 holes×diameter, exact Pawlak rod/valve confirmation, absolute air flow.

**Both important:** complete 1-D intake/exhaust geometry; operating-point exhaust temperature; same-setup motoring/friction.

The bounded search is terminated here. Further broad searching is unlikely to change the result; remaining gaps are OEM/service-document, author-data, or physical-measurement problems.

---

# Generated numeric files in this package

- `TV1_Quadri2018_digitized_traces_1deg.csv` — TV1 pressure/NHRR, all three fuel modes.
- `TV1_Quadri2018_digitized_traces_1deg.json`.
- `TV1_Quadri2018_digitization_peak_checks.csv`.
- `AVL5402_Pawlak2026_vector_digitized_traces_1deg.csv` — all six fuels, 25/35 N·m pressure/VHRR.
- `AVL5402_Pawlak2026_vector_digitized_data.json`.
- `AVL5402_Pawlak2026_DO_combustion_phasing.csv`.
- `AVL5402_Pawlak2026_DO_performance_derived.csv`.
- `AVL5402_Pawlak2026_efficiency_lambda_fuel_derived.csv`.
- `AVL5402_Pawlak2026_trace_peak_checks.csv`.
- `P3_Kirloskar_TV1_AVL5402_validation_pack_COMPLETE.json` — requested `{name,value,unit,grade,source}` records.
