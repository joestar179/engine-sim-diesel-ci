# Bounded search notes

The extension used three targeted search passes, then stopped.

## GM LSA
Searched for:
- exact 2009 CTS-V WOT airflow/fuel/boost datasets;
- SAE J1349/J2723 CTS-V data;
- TVS1900 application map;
- stock cam/rod geometry.

Recovered:
- SAE CPGM2_09CADCTSV Level 2 catalogue metadata;
- exact-build secondary 2.56 blower ratio;
- GM maximum fuel-demand statement;
- previously missed marine-family fuel-flow table;
- OEM-family bypass control data;
- exact GM stock-cam part specifications.

Not recovered publicly:
- exact automotive airflow/fuel/boost curves;
- exact application compressor map;
- charge-temperature curves;
- cylinder pressure.

## VW BLG
Searched for:
- authoritative supplier/model/displacement;
- full-load mass/fuel flow;
- charger maps and temperature data;
- valvetrain/rod geometry.

Recovered:
- secondary reproduction of a 2009 Eaton email identifying M24;
- tertiary 0.390 L/rev M24 claim.

Not recovered at D-grade:
- exact production displacement/datasheet;
- full-load flow;
- exact charger maps;
- valvetrain/rod dimensions;
- cylinder pressure.

No fourth speculative search pass was performed.
