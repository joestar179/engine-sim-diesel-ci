# S10 — Supercharged petrol validation pack

## Frozen validation cases

1. **GM LSA 6.2 L — 2009 Cadillac CTS-V**
   - Role: primary **quantitative positive-displacement supercharger** benchmark.
   - Production target: 2009 CTS-V LSA, stock pulley/calibration.
   - Important evidence split: exact 2009 CTS-V hardware/output data are marked **D**; the dense GM airflow and torque/power tables come from the 2011 GM Powertrain OEM application manual and are marked **F** because that manual explicitly describes its LSA as an OEM/marine variant and notes that variant hardware can differ.

2. **Volkswagen EA111 1.4 TSI Twincharger — BLG 125 kW**
   - Role: **twincharging architecture/control** benchmark: mechanical supercharger + turbocharger in series, clutch, bypass/regulating flap and handover.
   - Production target: BLG, 125 kW at 6000 rpm, 240 Nm at 1750–4500 rpm.

This pack intentionally does **not** substitute aftermarket measurements, generic compressor maps or simulation-calibrated parameters for production measurements.

---

## Evidence grades

- **D** — direct / exact configuration or exact production engine hardware.
- **F** — family / adjacent configuration. Useful, but not the frozen build.
- **R** — derived from D/F values; arithmetic stated or obvious from the table.
- **U** — not found in the bounded search.
- **D-digitised** — digitised from a plotted curve in an exact-configuration OEM source; approximate read-off, not an original numeric table.

Where an OEM source contains an ambiguous or internally inconsistent label, the ambiguity is retained instead of silently “correcting” it.

---

# CASE 1 — 2009 Cadillac CTS-V, GM LSA 6.2 L

## Intended simulator use

Use this case primarily to validate:

- mechanically driven positive-displacement compressor mass-flow behaviour;
- fixed mechanical drive ratio;
- integrated liquid-to-air charge cooling topology;
- full-load brake output;
- total engine air demand.

Do **not** use the generic Eaton R1900 map as a validation target. It is a family/model initializer only.

---

## A. Engine geometry

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Layout | 90° V8, OHV, 2 valves/cyl | D | GM 2009 CTS-V technical material / Techline |
| Displacement | 6.2 L / 6162 cm³ | D | GM 2009 CTS-V |
| Bore | 4.065 in = 103.25 mm | F | Chevrolet Performance LSA crate spec, p.4; same LSA architecture |
| Stroke | 3.622 in = 92.00 mm | F | Chevrolet Performance LSA crate spec, p.4 |
| Compression ratio | 9.1:1 | D | GM Techline Feb. 2009; Chevrolet crate spec agrees |
| Connecting-rod length | **U** | U | No primary/exact source retained in this bounded search |
| Chamber volume | 68 cm³ | F | Chevrolet Performance LSA crate spec, p.4 |
| Block | cast aluminium | D | GM 2009 CTS-V Techline |
| Crankshaft | forged steel | D | GM 2009 CTS-V Techline |
| Pistons | hypereutectic aluminium | D | GM 2009 CTS-V press material |
| Piston oil jets | present | D | GM 2009 CTS-V Techline |

### Configuration note

A contemporary Motor Trend specification lists **9.0:1**, while GM dealership Techline material for the 2009 CTS-V and the Chevrolet Performance LSA specification list **9.1:1**. For this pack, **9.1:1 is retained** because the GM technical source is preferred. The disagreement should remain visible in any audit trail.

---

## B. Valvetrain

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Architecture | OHV, hydraulic roller tappet | D/F | GM 2009 Techline + Chevrolet LSA crate spec |
| Intake valve head diameter | 2.16 in = 54.86 mm | F | Chevrolet LSA crate spec, p.4 |
| Exhaust valve head diameter | 1.59 in = 40.39 mm | F | Chevrolet LSA crate spec, p.4 |
| Valve lift | 0.480 in = 12.19 mm intake/exhaust | F | Chevrolet LSA crate spec, p.4 |
| Duration @ 0.050 in tappet lift | 198° intake / 216° exhaust | F | Chevrolet LSA crate spec, p.4 |
| Rocker ratio | 1.7:1 | F | Chevrolet LSA crate spec, p.4 |
| Seat-to-seat timing / opening & closing angles | **U** | U | 0.050-in duration is not sufficient to reconstruct seat timing |
| Full lift-vs-crank-angle profile | **U** | U | not found |
| VVT | **U in retained exact source set** | U | Do not assume a VVT schedule without a cited production source |

For a 1-D model, the valve diameters are usable; the valve event phasing and lift law still require a documented default or a separate source.

---

## C. Intake / exhaust / charge cooler

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Supercharger outlet charge cooler | integrated liquid-to-air | D | GM/Chevrolet LSA documentation |
| Cooler circuit | separate from engine coolant circuit | D/F | Chevrolet LSA crate spec, p.2 |
| Minimum recommended CAC coolant flow | 5.5 US gal/min = 20.8 L/min | F | Chevrolet LSA crate spec, p.2; installation requirement, **not measured test flow** |
| Recommended CAC coolant inlet | <95°F = <35°C | F | installation recommendation, not measured WOT temperature |
| Critical max CAC coolant inlet | <175°F = <79.4°C | F | safety limit, not normal operating target |
| Charge-cooler core volume | **U** | U | not found |
| Charge-cooler pressure-drop curve | **U** | U | not found |
| Intake runner lengths/areas | **U** | U | not found at 1-D-model resolution |
| Exhaust primary lengths/diameters | **U** | U | not found |
| Throttle bore | 87 mm | F | GM Powertrain 2011 OEM manual, Table 3.1.5-1 |

**Important:** the 35°C value is a recommended coolant inlet target. Treating it as measured charge temperature would be a category error.

---

## D. Supercharger

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Manufacturer / technology | Eaton, 6th-generation TVS | D | GM Techline Feb. 2009 |
| Type | Roots-type positive-displacement, 4-lobe helical rotors | D | GM Techline / Chevrolet LSA guide |
| Displacement | **1.9 L/rev** | D | GM Techline Feb. 2009 |
| Stock peak boost | **9.0 psi = 0.62 bar gauge** | D | GM Techline Feb. 2009 |
| Stock crank pulley OD | 7.8 in | F | Lingenfelter LSA pulley sheet |
| Stock SC pulley OD | 3.0 in | F | Lingenfelter LSA pulley sheet |
| Drive ratio | **2.60:1** | F | Lingenfelter table directly reports 2.6; 7.8/3.0 gives same rounded ratio |
| SC speed @ 6500 engine rpm | 16,900 rpm | F | Lingenfelter table |
| Exact production efficiency map | **U** | U | not found |
| Exact production compressor power map | **U** | U | not found |
| Bypass-valve calibration / area vs command | **U** | U | no exact calibration retained |
| Clutch | none in this case | D | mechanically driven continuously; no disengaging clutch in cited CTS-V architecture |

### Derived blower speed at GM airflow points

Using the F-grade 2.60 ratio:

| Engine rpm | GM airflow [g/s] | SC rpm |
|---:|---:|---:|
| 1200 | 79 | 3120 |
| 2000 | 132 | 5200 |
| 2800 | 182 | 7280 |
| 3600 | 268 | 9360 |
| 4400 | 290 | 11440 |
| 5200 | 437 | 13520 |

Airflow is **F**; SC rpm is **R**.

---

## E. Fuel, ignition and lambda

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Injection | sequential port fuel injection | D | GM Techline 2009 |
| High-throttle production fuel pressure | 65 psi | F | Chevrolet LSA crate installation guide |
| Moderate-load fuel pressure | 58 psi | F | same |
| Light-load fuel pressure | 36 psi | F | same |
| Fuel-system capacity requirement | 65 US gal/h at 65 psi | F | **capacity requirement, not engine fuel consumption** |
| Fuel | premium unleaded | D/F | GM/Chevrolet |
| Spark plug | GM 12571165 / ACDelco 41-104 | F | crate guide |
| Spark-plug gap | 0.040 in | F | crate guide |
| WOT spark advance vs rpm/load | **U** | U | not found |
| WOT lambda / AFR | **U** | U | not found |
| Actual full-load fuel flow | **U** | U | not found |

Do not convert the 65 gal/h fuel-system capacity into BSFC or WOT fuel consumption.

---

## G. Full-load torque / power

### Exact 2009 CTS-V anchor

- **556 hp (415 kW) @ 6100 rpm — D**
- **551 lb-ft (747 N·m) @ 3800 rpm — D**

These are GM's production 2009 CTS-V figures.

### Dense GM LSA table — F

GM Powertrain's 2011 Gen IV OEM application manual states that the performance table was obtained with engines in automotive dress per SAE J2723. However, the same manual explicitly distinguishes its OEM/marine LSA variant from the exact automotive build; therefore the dense curve is retained as **F**, not D.

| rpm | hp | lb-ft |
|---:|---:|---:|
| 1600 | 123 | 403 |
| 2000 | 172 | 450 |
| 2400 | 218 | 475 |
| 2800 | 272 | 510 |
| 3200 | 317 | 519 |
| 3600 | 362 | 528 |
| 4000 | 418 | 546 |
| 4400 | 450 | 537 |
| 4800 | 491 | 536 |
| 5200 | 510 | 515 |
| 5600 | 549 | 515 |

The CSV sidecar adds SI conversions and R-grade BMEP.

---

## H. Fuel and air flow

### Air flow — F

GM Powertrain 2011 application manual, p.40, Table 3.1.5-2:

| rpm | air flow [g/s] |
|---:|---:|
| 1200 | 79 |
| 2000 | 132 |
| 2800 | 182 |
| 3600 | 268 |
| 4400 | 290 |
| 5200 | 437 |

The manual describes these as **marine-engine airflow requirements measured under GM-specific test conditions**. They are valuable measurements but are not exact 2009 CTS-V data.

### Fuel flow at same points

**U.**

This is the main missing output for closing a full brake thermal-efficiency / BSFC validation loop.

---

## I. Cylinder pressure

**U — no validation-grade crank-angle cylinder-pressure trace found for the frozen 2009 CTS-V LSA build.**

Do not substitute a GT-Power trace or a generic LS combustion trace and label it measured.

---

## J. Boost, charge temperature, supercharger drive power

| Output | Status |
|---|---|
| Peak stock boost | **D: 9.0 psi gauge** |
| Boost vs engine rpm | **U** as a measured numeric curve |
| Charge temperature vs rpm/load | **U** |
| CAC coolant design bounds | available, but installation requirements rather than test outputs |
| SC shaft power vs rpm/PR | **U** |
| Generic R1900 family limits | available as MODEL-DERIVED initializer only |

---

## LSA — MODEL-DERIVED inputs allowed for simulation, but not validation evidence

1. **Eaton current R1900 map** — family map only.
   - typical max operating speed: 18,000 rpm;
   - peak pressure ratio: 1.8;
   - corrected airflow capability: 2426.06 kg/h at 100 kPa, 25°C reference inlet.
   - Eaton explicitly states that the displayed map is representative for sizing and that specific application performance varies.
   - Grade for the frozen CTS-V: **F / MODEL-DERIVED INPUT**, never D.

2. Missing bypass effective area, cooler pressure drop and exact port geometry may be calibrated/defaulted, but each such value must stay in the MODEL-DERIVED section of a simulator case file.

3. Do not tune the generic R1900 map against all six GM airflow points and then use the same six points as validation. Preserve hold-out points.

---

## LSA validation targets

Recommended split:

- **Calibration / initialization:** generic R1900 map shape; one or two F airflow points if necessary.
- **Validation:** remaining GM airflow points + dense F torque curve + exact D peak 2009 CTS-V output.
- **Not currently validated:** cylinder pressure, exact compressor efficiency, charge temperature, SC shaft power.

---

# CASE 2 — Volkswagen EA111 1.4 TSI Twincharger, BLG 125 kW

## Intended simulator use

This is retained specifically because it covers a topology not represented elsewhere:

**mechanical supercharger → turbocharger compressor → air-to-air intercooler → throttle → engine**

with:

- electromagnetic clutch;
- regulating/bypass flap;
- supercharger/turbo overlap;
- supercharger-to-turbo handover;
- full-load series compression.

It is therefore a control/topology benchmark even though the exact compressor map is missing.

---

## A. Engine geometry

VW SSP 359, p.5:

| Quantity | Value | Grade |
|---|---:|:---:|
| Engine code | BLG | D |
| Layout | inline-4 | D |
| Displacement | **1390 cm³** | D |
| Bore | **76.5 mm** | D |
| Stroke | **75.6 mm** | D |
| Valves/cyl | 4 | D |
| Compression ratio | **10.0:1** | D |
| Connecting-rod length | **U** | U |
| Block | grey cast iron, open deck | D |
| Crankshaft | forged steel | D |
| Piston | die-cast aluminium, graphite-coated skirt | D |
| Piston-pin diameter | 19 mm | D |

---

## B. Valvetrain

| Quantity | Value | Grade | Note |
|---|---:|:---:|---|
| DOHC, 4 valves/cyl | yes | D | SSP 359 |
| Inlet cam continuous adjustment | yes | D | SSP 359 |
| Inlet cam adjustment range | **40° crank angle max** | D | SSP 359 p.7 |
| Valve head diameters | **U** | U | not found in retained exact source |
| Max valve lift | **U** | U | not found |
| Seat timing | **U** | U | not found |
| Full lift curve | **U** | U | not found |

The inlet VVT capability is known, but the production schedule versus speed/load is not.

---

## C. Intake / exhaust / intercooler

VW's exact gas path is documented:

**air filter → regulating flap / mechanical SC path → turbocharger compressor → intercooler → throttle → intake manifold**

SSP 359 identifies pressure/temperature sensors before/after the relevant charging stages:

- **G583 + G520**: pressure and intake-air temperature behind the mechanical supercharger/regulating-flap region;
- **G31 + G299**: charge pressure and temperature before the throttle;
- **G71 + G42**: manifold pressure and temperature.

The ECU uses pressure, temperature and engine speed to calculate inducted air mass.

| Quantity | Value | Grade |
|---|---:|:---:|
| Intercooler | air-to-air | D |
| Charge air before cooler | may reach **~200°C** | D, descriptive upper value |
| Cooler target description | cools to just above ambient | D qualitative |
| Intercooler volume | **U** | U |
| Intercooler Δp curve | **U** | U |
| Intake runner dimensions | **U** | U |
| Exhaust manifold / runner dimensions | **U** | U |
| Turbo integrated with exhaust manifold | yes | D |
| Exhaust manifold temperature capability | up to **1050°C** | D |

---

## D. Mechanical supercharger + twincharging control

| Quantity | Value | Grade | Source / note |
|---|---:|:---:|---|
| Mechanical charger | two-rotor positive-displacement unit | D | VW SSP 359 |
| VW wording | “twin-screw” because of rotor shape | D | VW SSP 359 |
| Supplier / exact model | **U** | U | no authoritative supplier/model retained |
| Displacement/rev | **U** | U | not found |
| Exact efficiency map | **U** | U | not found |
| Drive ratio | **5.0 × crank speed** | D | VW SSP 359 |
| Maximum SC speed | **17,500 rpm** | D | VW SSP 359 |
| Clutch | maintenance-free electromagnetic clutch | D | VW SSP 359 |
| Bypass / regulating device | regulating flap control unit J808 | D | VW SSP 359 |
| SC maximum pressure | about **1.75 bar absolute** | D | VW SSP 359 |
| Combined intake-manifold pressure | up to **2.5 bar absolute** | D | VW SSP 359 |
| SC continuous-required region | to **2400 rpm**, above a torque-demand threshold | D | VW SSP 359 |
| SC demand-dependent assist | to **3500 rpm** | D | VW SSP 359 |
| Turbo-only capability | from ~**3500 rpm** | D | VW SSP 359 |
| SC thermal protection | SC power throttled above **130°C** at G520 | D | VW SSP 359 |
| Clutch control | PWM with current measurement for soft engagement | D | VW SSP 359 |

### Derived SC speed

| Engine rpm | SC rpm |
|---:|---:|
| 1000 | 5000 |
| 1500 | 7500 |
| 2000 | 10000 |
| 2400 | 12000 |
| 3000 | 15000 |
| 3500 | **17500** |

All SC-rpm values are **R** from the exact D-grade 5:1 ratio.

The 3500-rpm handover boundary and 17,500-rpm maximum are mechanically self-consistent: 3500 × 5 = 17,500 rpm.

---

## E. Fuel, spark and lambda

| Quantity | Value | Grade |
|---|---:|:---:|
| Injection | direct petrol injection | D |
| Engine management | Bosch Motronic MED 9.5.10 | D |
| HP fuel pressure operating range | 50–150 bar | D |
| HP relief valve | opens at 172.5 bar | D |
| Fuel | RON 98 specified for BLG; RON 95 allowed with penalty | D |
| Homogeneous mode | lambda 1 | D |
| Exhaust manifold permits lambda≈1 over almost all map | D qualitative |
| WOT lambda table | **U** | U |
| Spark advance table | **U** | U |
| Actual fuel-flow curve | **U** | U |

---

## G. Full-load torque / power

### OEM exact headline values

- **125 kW @ 6000 rpm — D**
- **240 N·m @ 1750–4500 rpm — D**

### Digitised full-load torque curve

Figure **S359_094**, VW SSP 359 p.5, was visually digitised at approximately 250–500 rpm effective resolution. Practical reading uncertainty is roughly **±5 N·m**.

| rpm | torque [N·m], digitised | power [kW], R from torque |
|---:|---:|---:|
| 1250 | 175 | 22.9 |
| 1500 | 210 | 33.0 |
| 1750 | 240 | 44.0 |
| 2000 | 240 | 50.3 |
| 3000 | 240 | 75.4 |
| 4000 | 240 | 100.5 |
| 4500 | 240 | 113.1 |
| 5000 | 230 | 120.4 |
| 5500 | 215 | 123.8 |
| 6000 | 199 | 125.0 |
| 6500 | 185 | 125.9 |

The final point is plot-read uncertainty rather than an assertion that rated power is exactly 125.9 kW. Use the OEM **125 kW @ 6000 rpm** datum as the exact anchor.

---

## H. Fuel and air flow

| Output | Status |
|---|---|
| Actual measured full-load fuel flow | **U** |
| Actual measured engine air-flow table | **U** |
| ECU air-mass calculation method | **D** — calculated from pressure/temperature signals and speed |
| MAF requirement | not required by the retained SSP description |

This is the principal reason BLG is a weaker quantitative thermodynamic benchmark than the LSA.

---

## I. Cylinder pressure

**U — no exact BLG crank-angle cylinder-pressure trace found.**

---

## J. Boost / charge temperature / SC power

### Full-load charging curve

VW SSP 359 Figure **S359_109** gives the full-load pressure-ratio behaviour of:

- the mechanical compressor;
- turbocharger;
- combined system;
- comparison simple-turbo system.

The plot's y-axis is literally labelled **“Pressure ratio [bar]”** by VW. Pressure ratio is dimensionless; the pack preserves the OEM label but stores the digitised values as ratios.

Approximate visual digitisation:

| rpm | combined PR | mechanical-SC PR |
|---:|---:|---:|
| 1000 | 2.35 | 1.72 |
| 1500 | 2.50 | 1.55 |
| 2000 | 2.32 | 1.28 |
| 2500 | 2.00 | 1.00 |
| 3000 | 1.96 | — |
| 4000 | 1.90 | — |
| 5000 | 1.88 | — |
| 6000 | 1.72 | — |
| 7000 | 1.50 | — |

Use approximately **±0.05** as a practical digitisation uncertainty.

### Important interpretation

- Up to 2400 rpm at sufficiently high torque demand, the SC is continuously active.
- From 2400–3500 rpm it can be re-engaged transiently.
- From about 3500 rpm the turbocharger can meet required boost alone.
- The regulating flap is not simply binary: opening it recirculates/bypasses part of the flow and reduces both SC boost and mechanical drive power.

### Charge temperature

VW states that charge air after the turbocharger can reach **up to ~200°C** before the intercooler and that the cooler reduces it to just above ambient. This is an OEM physical description, not a full measured temperature-vs-speed curve.

### Mechanical SC drive power

No numeric shaft-power curve was found. The SSP states qualitatively that opening the regulating flap reduces required SC drive power.

---

## BLG — MODEL-DERIVED inputs allowed for simulation, but not validation evidence

The following remain model inputs rather than measured production hardware:

- exact SC displacement per revolution;
- SC efficiency map;
- SC internal leakage law;
- regulating-flap effective area vs command;
- exact turbo compressor/turbine maps;
- intercooler volume and pressure-loss correlation;
- full intake/exhaust runner geometry;
- WOT spark and enrichment schedule.

Do **not** assign an Eaton model purely because secondary material does so. The OEM source is sufficient to implement the topology without making that unsupported identification.

---

# Validation strategy

## Case 1 — LSA

**Primary validation observables**

1. engine airflow versus rpm — F, measured GM test table;
2. brake torque/power versus rpm — F dense GM table;
3. exact 2009 CTS-V peak output — D;
4. peak stock boost — D.

**What this can validate well**

- total engine/compressor mass-flow scaling;
- mechanically driven blower speed coupling;
- integrated effect of compressor + intercooler + engine on brake output.

**What it cannot independently validate yet**

- exact compressor efficiency map;
- bypass calibration;
- compressor shaft power;
- charge-temperature prediction;
- cylinder-pressure prediction.

---

## Case 2 — BLG Twincharger

**Primary validation observables**

1. exact torque/power anchors and OEM plotted curve;
2. 5:1 supercharger drive ratio;
3. 17,500-rpm SC limit;
4. 2400-rpm continuous-SC boundary;
5. 2400–3500 rpm demand-dependent SC assist;
6. ~3500-rpm turbo-only handover;
7. up to 2.5 bar absolute manifold pressure;
8. full-load charging-system pressure-ratio curve, Fig. S359_109;
9. 130°C SC thermal-protection threshold.

**What this can validate well**

- series SC+turbo gas-path topology;
- clutch engagement state;
- bypass/regulating-flap logic;
- SC speed limit;
- boost handover;
- overall pressure-ratio behaviour.

**What it cannot independently validate yet**

- exact SC mass-flow/efficiency;
- fuel consumption;
- full charge-temperature curve;
- compressor drive power;
- cylinder pressure.

---

# Recommended simulator acceptance tests

## LSA

1. At the six GM airflow speeds, compare predicted engine air mass flow with the F dataset.
2. Preserve at least 2–3 airflow points as hold-out validation points if the generic R1900 map is tuned.
3. Compare brake torque/power to the F GM curve and exact D peak output.
4. Do not claim compressor-efficiency validation unless a production TVS1900 map or shaft-power/temperature data is added later.

## BLG

1. Implement hard SC speed relation: `N_SC = 5 N_engine` while clutch engaged.
2. Continuous high-load SC availability to 2400 rpm.
3. Demand-dependent transient assist between 2400 and 3500 rpm.
4. Turbo-only above ~3500 rpm.
5. Regulating flap must be able to unload/recirculate SC flow rather than simply block the compressor.
6. Validate combined full-load pressure-ratio trend against S359_109.
7. Enforce SC temperature protection behaviour above 130°C at the relevant sensor location.
8. Do not fit an assumed SC displacement to the OEM boost curve and then treat the same curve as independent validation.

---

# Remaining high-value gaps

## LSA
- exact stock production TVS1900 efficiency / flow / power map;
- bypass valve effective area and control law;
- charge-air temperature vs operating point;
- actual fuel flow/BSFC matched to airflow;
- cylinder pressure;
- 1-D intake/exhaust geometry.

## BLG
- authoritative SC supplier/model/displacement;
- exact SC compressor map;
- measured air/fuel flow;
- measured charge temperatures at G520/G299/G42;
- SC drive power;
- exact turbo maps;
- cylinder pressure;
- detailed 1-D gas-path dimensions.

These gaps were searched in a bounded manner. Further broad searching was stopped because weaker secondary repetition was unlikely to change the implementation decision.

---

# Source inventory

## GM / Cadillac / LSA

### S1 — Chevrolet Performance, LSA Crate Engine Specifications, P/N 19244109
**Type:** OEM PDF.  
**Useful pages:** p.2 supercharger/intercooler/fuel-system requirements; p.4 engine geometry/valvetrain.  
**URL:** https://www.chevrolet.com/content/dam/chevrolet/na/us/english/index/performance/resources/installation-guides/crate-engines/01-images/lsa-crate-engine-19260164.pdf

Key retained items:
- Roots-type positive-displacement SC, four-lobe helical rotors;
- integrated liquid-to-air intercooler;
- 5.5 US gal/min minimum recommended CAC coolant flow;
- <95°F recommended CAC coolant inlet; <175°F critical maximum;
- bore/stroke, CR, valve diameters, lift, 0.050-in duration.

### S2 — GM Techline News, February 2009, Vol. 11 No. 2, “2009 Cadillac CTS-V”
**Type:** GM dealership technical publication, mirrored HTML transcript.  
**URL:** https://manualzilla.com/doc/7320517/2009-cadillac-cts-v-identifying-aftermarket-non

Key retained items:
- 1.9 L/rev sixth-generation Eaton TVS;
- 9 psi maximum boost;
- 9.1:1 CR;
- sequential fuel injection;
- 2009 CTS-V-specific hardware details.

### S3 — GM Media 2009 CTS-V press material, mirror
**Type:** GM Media press release mirrored by Cadillac V-Net.  
**URL:** https://www.cadillacvnet.com/tech-center/cts-v/2009/2009_cadillac_cts-v_press_release1.html

Key retained items:
- 556 hp @ 6100 rpm;
- 551 lb-ft / 747 Nm;
- intercooled four-lobe LSA architecture.

### S4 — GM Powertrain, 2011 Gen IV V8 Engine OEM Sales application manual, mirrored on Scribd
**Type:** GM Powertrain manual, third-party mirror.  
**Useful pages:** p.9 performance table; p.40 airflow / throttle tables.  
**URL:** https://www.scribd.com/document/408291165/2016-GM-Gen4-V8-Engine-Service-Manual-pdf

Key retained items:
- dense LSA SAE J2723 torque/power table;
- 87-mm throttle for LSA group;
- LSA airflow table;
- explicit warning that OEM/marine variant can differ from exact automotive application.

### S5 — Lingenfelter LSA Pulley Sheet v1.1
**Type:** aftermarket engineering installation table.  
**URL:** https://www.lingenfelter.com/PRI2014sheets/LSA%20Pulley%20Sheet%201.1.pdf

Key retained items:
- stock 7.8-in crank / 3.0-in SC pulley;
- 2.6 ratio;
- 16,900 SC rpm at 6500 engine rpm.

### S6 — Eaton TVS R1900 current product page
**Type:** manufacturer family/product page; not exact CTS-V application map.  
**URL:** https://www.eaton.com/us/en-us/catalog/engine-solutions/tvs-r1900.html

Key retained items:
- 18,000-rpm typical max;
- 1.8 peak PR;
- 2426.06 kg/h corrected flow;
- Eaton caveat that map is representative and application performance varies.

---

## Volkswagen BLG

### V1 — Volkswagen Self-study Programme 359: “1.4l TSI Engine with Dual-charging”
**Type:** OEM service-training PDF.  
**URL:** https://www.volkspage.net/technik/ssp/ssp/SSP_359.pdf

Important pages / figures:
- p.5: technical data and torque/power figure S359_094;
- p.7: continuous inlet-cam adjustment, 40° crank;
- pp.12–18: twincharging topology, working ranges, clutch, SC drive, 5:1 ratio, 17,500-rpm limit, regulating flap;
- p.14: up to 2.5 bar absolute manifold pressure;
- p.20: air-to-air intercooler and charge-air temperature description;
- p.31: boost-pressure regulation, Figure S359_109;
- p.32: G583/G520 and 130°C protection threshold;
- p.44: current sensing / PWM clutch actuation.

### V2 — secondary contemporary technical description of Twincharger stage pressure ratios
**Type:** secondary; retained only as family/context evidence.  
A contemporaneous technical description attributed to VW reports approximately 2.5 bar absolute at 1500 rpm with the two stages at about equal PR (~1.53 each). Because `1.53 × 1.53 = 2.34`, not 2.5, these rounded figures must not be forced simultaneously in calibration. The OEM SSP pressure curve is preferred.

---

# Pack files

- `README.md` — this validation report.
- `lsa_airflow.csv` — GM airflow table plus R supercharger speeds.
- `lsa_performance.csv` — dense GM LSA torque/power table plus SI conversions/BMEP.
- `vw_blg_torque_digitized.csv` — digitised BLG torque curve and R power/BMEP.
- `vw_blg_boost_pr_digitized.csv` — digitised SSP359 full-load pressure-ratio curves.

